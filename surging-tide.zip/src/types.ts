export type ProductCategory = 'hoodies' | 'tees' | 'jeans';

export interface Review {
  id: string;
  rating: number;
  comment: string;
  author: string;
  date: string;
  verified: boolean;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  longDescription: string;
  category: ProductCategory;
  sizes: string[];
  colors: string[];
  primaryImage: string;
  secondaryImage: string;
  rating: number;
  reviews: Review[];
  details: string[];
}

export interface CartItem {
  id: string; // unique key combining product.id + size + color
  product: Product;
  selectedSize: string;
  selectedColor: string;
  quantity: number;
}

export interface VoteItem {
  id: string;
  name: string;
  description: string;
  image: string;
  votes: number;
  voted: boolean;
  percentage?: number;
}

export interface BlogPost {
  id: string;
  title: string;
  summary: string;
  content: string;
  date: string;
  readTime: string;
  image: string;
  author: string;
}

export interface LookbookItem {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  productName: string;
  productId: string;
}
