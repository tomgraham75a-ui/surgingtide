import React, { useState, useRef, MouseEvent } from 'react';
import { Heart, ShoppingBag, Eye, Star } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  key?: any;
  product: Product;
  onNavigateToProduct: (id: string) => void;
  onQuickAddToCart: (product: Product) => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
}

export default function ProductCard({
  product,
  onNavigateToProduct,
  onQuickAddToCart,
  isWishlisted,
  onToggleWishlist,
}: ProductCardProps) {
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [shimmerX, setShimmerX] = useState(50);
  const [shimmerY, setShimmerY] = useState(50);
  const [isHovered, setIsHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  // Parallax 3D Card Tilt Math
  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    // Mouse coordinates relative to card center
    const x = e.clientX - rect.left - width / 2;
    const y = e.clientY - rect.top - height / 2;

    // Limits tilt rotation to max 12 degrees
    const rX = -(y / (height / 2)) * 12;
    const rY = (x / (width / 2)) * 12;

    setRotateX(rX);
    setRotateY(rY);

    // Calculate mouse percentage for gloss shimmer moving highlighting
    const sX = ((e.clientX - rect.left) / width) * 100;
    const sY = ((e.clientY - rect.top) / height) * 100;
    setShimmerX(sX);
    setShimmerY(sY);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setIsHovered(false);
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className="relative select-none group w-full cursor-pointer rounded-none bg-[#0a0a0a] border border-[#C0C0C0]/10 hover:border-[#6B7BFF] p-4 transition-all duration-300 shadow-[0_0_15px_rgba(0,0,0,0.5)] flex flex-col justify-between"
      style={{
        perspective: '1000px',
        transformStyle: 'preserve-3d',
        transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
        transition: isHovered ? 'border-color 0.3s, box-shadow 0.3s' : 'transform 0.5s ease, border-color 0.3s, box-shadow 0.3s',
      }}
      id={`product-card-${product.id}`}
    >
      {/* Gloss Highlight Overlay */}
      {isHovered && (
        <div
          className="absolute inset-0 pointer-events-none rounded-none z-20 mix-blend-color-dodge opacity-20 transition-opacity duration-300"
          style={{
            background: `radial-gradient(circle at ${shimmerX}% ${shimmerY}%, rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 60%)`,
          }}
        />
      )}

      {/* Blue outer glow when hovered */}
      <div
        className={`absolute inset-0 -z-10 bg-[#6B7BFF]/5 rounded-none blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
      />

      {/* CARD MAIN WORK */}
      <div className="relative overflow-hidden rounded-none bg-[#0a0a0a] aspect-square w-full border border-[#C0C0C0]/5">
        {/* Collection badge overlay */}
        <span className="absolute top-3 left-3 bg-black border border-[#C0C0C0]/20 px-2.5 py-1 rounded-none text-[8px] sm:text-[9px] font-mono font-black text-[#6B7BFF] uppercase tracking-widest z-10">
          {product.category}
        </span>

        {/* Wishlist Toggle Heart Action */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-3 right-3 p-2 bg-black border border-zinc-800 hover:border-[#6B7BFF] rounded-none z-10 transition-colors ${
            isWishlisted ? 'text-[#6B7BFF]' : 'text-[#C0C0C0] hover:text-[#6B7BFF]'
          }`}
          id={`wishlist-toggle-${product.id}`}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-[#6B7BFF]' : ''}`} />
        </button>

        {/* Dynamic crossfading images */}
        <div 
          onClick={() => onNavigateToProduct(product.id)}
          className="w-full h-full relative"
        >
          {/* Default Image */}
          <img
            src={product.primaryImage}
            alt={product.name}
            className={`w-full h-full object-cover transition-transform duration-700 ${
              isHovered ? 'scale-105 opacity-0' : 'scale-100 opacity-100'
            }`}
            referrerPolicy="no-referrer"
          />

          {/* Lifestyle / Detail Hover Image */}
          <img
            src={product.secondaryImage}
            alt={`${product.name} Lifestyle`}
            className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ${
              isHovered ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
            }`}
            referrerPolicy="no-referrer"
          />
        </div>

        {/* QUICK ADD ACTION OVERLAY - Slide up on hover */}
        <div
          className={`absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black via-black/90 to-transparent z-10 flex items-center justify-between transition-all duration-300 select-none ${
            isHovered ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0 pointer-events-none'
          }`}
        >
          <button
            onClick={(e) => {
              e.stopPropagation();
              onQuickAddToCart(product);
            }}
            id={`quick-add-cart-${product.id}`}
            className="flex-1 py-3 bg-[#6B7BFF] hover:bg-[#5B6BEF] text-white hover:opacity-90 font-sans font-black text-[10px] sm:text-xs tracking-[0.2em] uppercase rounded-none flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg"
          >
            <ShoppingBag className="w-3.5 sm:w-4 h-3.5 sm:h-4" />
            <span>QUICK ADD</span>
          </button>
          
          <button
            onClick={(e) => {
              e.stopPropagation();
              onNavigateToProduct(product.id);
            }}
            id={`view-details-${product.id}`}
            className="ml-2 p-3 border border-zinc-800 hover:border-[#6B7BFF] text-[#C0C0C0] hover:text-[#6B7BFF] rounded-none bg-black/60 transition-all cursor-pointer"
            title="View Details"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* INFO AREA ACCORDING TO SPECS */}
      <div className="pt-3 flex flex-col justify-between flex-1">
        <div>
          <div className="flex justify-between items-start gap-2">
            <h3
              onClick={() => onNavigateToProduct(product.id)}
              className="text-xs sm:text-sm font-sans font-black tracking-widest text-[#E8E8E8] hover:text-[#6B7BFF] cursor-pointer transition-colors uppercase leading-snug line-clamp-1 flex-1 text-left"
            >
              {product.name}
            </h3>
            <span className="font-mono text-xs font-bold text-[#E8E8E8] tracking-wider whitespace-nowrap shrink-0">
              ${product.price} USD
            </span>
          </div>

          <p className="text-[10px] sm:text-[11px] text-zinc-500 font-sans tracking-wide mt-1 leading-snug line-clamp-2 text-left">
            {product.description}
          </p>
        </div>

        {/* Stars rating small indication */}
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-zinc-900">
          <div className="flex items-center space-x-1">
            <Star className="w-3 h-3 text-[#6B7BFF] fill-[#6B7BFF]" />
            <span className="text-[10px] font-mono text-[#C0C0C0]">{product.rating}</span>
          </div>
          <span className="text-[9px] font-mono text-zinc-600 uppercase">
            {product.reviews.length} VERIFIED OPINIONS
          </span>
        </div>
      </div>
    </div>
  );
}
