import React, { useState, useEffect } from 'react';
import Logo from './Logo';

interface LoadingScreenProps {
  onComplete: () => void;
}

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [phase, setPhase] = useState<'enter' | 'ripple' | 'fade-out'>('enter');

  useEffect(() => {
    // 1. Enter state shows silver trident starting to glow
    const phase1 = setTimeout(() => {
      setPhase('ripple');
    }, 1200);

    // 2. Ripple water waves activate
    const phase2 = setTimeout(() => {
      setPhase('fade-out');
    }, 2800);

    // 3. Complete dissolves overlay
    const phase3 = setTimeout(() => {
      onComplete();
    }, 3400);

    return () => {
      clearTimeout(phase1);
      clearTimeout(phase2);
      clearTimeout(phase3);
    };
  }, [onComplete]);

  return (
    <div
      id="cinematic-loader-mask"
      className={`fixed inset-0 bg-[#000000] z-50 flex flex-col items-center justify-center select-none overflow-hidden transition-all duration-1000 ${
        phase === 'fade-out' ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      <style>{`
        @keyframes ripple-ring {
          0% { transform: scale(0.6); opacity: 0; }
          40% { opacity: 0.4; }
          100% { transform: scale(1.6); opacity: 0; }
        }
        .ripple-anim {
          animation: ripple-ring 2s cubic-bezier(0.1, 0.8, 0.3, 1) infinite;
        }
      `}</style>

      {/* Ripple/Wave Particle Effect behind the logo */}
      {phase === 'ripple' && (
        <div className="absolute inset-0 z-0 flex items-center justify-center">
          <div className="absolute w-[200px] h-[200px] rounded-full border border-[#6B7BFF]/30 ripple-anim" />
          <div className="absolute w-[350px] h-[350px] rounded-full border border-[#6B7BFF]/15 ripple-anim [animation-delay:0.5s]" />
          <div className="absolute w-[500px] h-[500px] rounded-full border border-[#6B7BFF]/5 ripple-anim [animation-delay:1s]" />
          <div className="absolute w-full h-[3px] bg-gradient-to-r from-transparent via-[#6B7BFF]/20 to-transparent blur-md animate-pulse" />
        </div>
      )}

      {/* Center Rising Logo */}
      <div
        className={`relative z-10 transition-all duration-1000 transform ${
          phase === 'enter' ? 'translate-y-6 opacity-0 scale-95' : 'translate-y-0 opacity-100 scale-100'
        }`}
      >
        <Logo size="xl" className="filter drop-shadow-[0_0_30px_rgba(107,123,255,0.3)]" />
      </div>

      {/* System Status Tracker at very bottom border */}
      <div className="absolute bottom-8 left-0 right-0 text-center font-mono text-[9px] text-zinc-700 tracking-[0.5em] uppercase">
        ESTAB_APPAR_INIT // TIDE_RESONATORS_ONLINE
      </div>
    </div>
  );
}
