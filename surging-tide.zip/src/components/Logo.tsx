import React from 'react';

interface LogoProps {
  className?: string; // custom classes for scaling
  iconOnly?: boolean; // toggle just rendering the trident icon
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export default function Logo({ className = '', iconOnly = false, size = 'md' }: LogoProps) {
  // Dimension definitions
  const sizeMap = {
    sm: { iconWidth: 28, textClass: 'text-sm', subClass: 'text-[9px]' },
    md: { iconWidth: 48, textClass: 'text-xl', subClass: 'text-[11px]' },
    lg: { iconWidth: 84, textClass: 'text-2xl sm:text-3xl', subClass: 'text-xs sm:text-sm' },
    xl: { iconWidth: 160, textClass: 'text-4xl sm:text-5xl', subClass: 'text-sm sm:text-base' },
  };

  const activeSize = sizeMap[size];

  // SVG Trident with custom metallic silver reflections
  const renderTrident = (width: number) => {
    const height = width * 1.25;
    return (
      <svg
        width={width}
        height={height}
        viewBox="0 0 100 125"
        className="drop-shadow-[0_0_15px_rgba(107,123,255,0.45)] hover:scale-105 transition-transform duration-300"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Silver metallic reflections gradient */}
          <linearGradient id="silver-trident" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#C0C0C0" />
            <stop offset="25%" stopColor="#FFFFFF" />
            <stop offset="50%" stopColor="#909090" />
            <stop offset="75%" stopColor="#E8E8E8" />
            <stop offset="100%" stopColor="#707070" />
          </linearGradient>
          
          {/* Electric blue glow for logo base elements */}
          <filter id="blue-glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Dynamic Trident Graphic Path */}
        <path
          d="M50,5 L54,18 L64,15 L50,32 L36,15 L46,18 Z
             M50,15 L50,70 L48,70 L48,15 Z"
          fill="url(#silver-trident)"
        />
        {/* Left Prong */}
        <path
          d="M26,30 C24,40 28,50 38,55 C34,50 34,42 34,35 L26,30"
          fill="url(#silver-trident)"
        />
        {/* Right Prong */}
        <path
          d="M74,30 C76,40 72,50 62,55 C66,50 66,42 66,35 L74,30"
          fill="url(#silver-trident)"
        />
        {/* Center Main Spikes */}
        <path
          d="M50,15 L58,40 C58,55 52,58 50,58 C48,58 42,55 42,40 L50,15"
          fill="url(#silver-trident)"
        />
        {/* Base Shaft Details */}
        <path
          d="M50,58 L50,95 L46,92 L50,89 L46,86 L50,83 L46,80 L50,58"
          fill="url(#silver-trident)"
        />
        {/* Base Crossguard Wing */}
        <path
          d="M38,55 C44,58 56,58 62,55 C56,54 44,54 38,55"
          fill="url(#silver-trident)"
        />
        {/* Glowing Energy Node */}
        <circle cx="50" cy="58" r="4" fill="#6B7BFF" className="animate-pulse" filter="url(#blue-glow)" />
      </svg>
    );
  };

  if (iconOnly) {
    return <div className={`flex items-center justify-center ${className}`}>{renderTrident(activeSize.iconWidth)}</div>;
  }

  return (
    <div className={`flex flex-col items-center justify-center text-center font-sans tracking-wide select-none ${className}`}>
      {/* 1. Large Silver Trident Icon */}
      {renderTrident(activeSize.iconWidth)}

      {/* 2. Brand block: EST. [Trident] 2026 */}
      <div className="flex items-center justify-center space-x-6 sm:space-x-8 mt-2 w-full text-zinc-400 font-mono text-xs tracking-widest text-[#C0C0C0] font-sans uppercase">
        <span className="opacity-80">EST.</span>
        <span className="w-1.5 h-1.5 bg-[#6B7BFF] rounded-full animate-ping"></span>
        <span className="opacity-80">2026</span>
      </div>

      {/* 3. large SURGING TIDE title */}
      <h1 className={`font-black tracking-[0.2em] font-sans text-transparent bg-clip-text bg-gradient-to-r from-[#6B7BFF] via-[#A5B4FC] to-[#5B6BEF] uppercase ${activeSize.textClass} mt-1`}>
        SURGING TIDE
      </h1>

      {/* 4. tagline */}
      <p className={`font-medium tracking-[0.3em] text-[#C0C0C0] uppercase font-sans ${activeSize.subClass} mt-1 opacity-90 italic`}>
        Ride The Style Wave
      </p>
    </div>
  );
}
