import React, { useState, useEffect, useRef } from 'react';
import { Search as SearchIcon, X, ArrowRight } from 'lucide-react';
import { Product } from '../types';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onNavigateToProduct: (id: string) => void;
}

export default function SearchOverlay({ isOpen, onClose, products, onNavigateToProduct }: SearchOverlayProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Product[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    const cleanQuery = query.toLowerCase().trim();
    const filtered = products.filter(
      (p) =>
        p.name.toLowerCase().includes(cleanQuery) ||
        p.description.toLowerCase().includes(cleanQuery) ||
        p.category.toLowerCase().includes(cleanQuery)
    );
    setResults(filtered);
  }, [query, products]);

  const handleKeyPress = (e: KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, []);

  if (!isOpen) return null;

  const hotSearches = ['HOODIE', 'TEE', 'JEANS', 'METALLIC', 'TEMPEST'];

  return (
    <div
      id="search-overlay-container"
      className="fixed inset-0 bg-[#000000]/95 backdrop-blur-md z-50 flex flex-col px-6 pt-24 sm:px-12"
    >
      {/* Absolute Close Header */}
      <div className="absolute top-6 right-6 sm:right-12">
        <button
          onClick={onClose}
          id="search-close-button"
          className="p-3 bg-[#0D0D1A] border border-[#6B7BFF]/20 text-[#C0C0C0] hover:text-[#6B7BFF] hover:border-[#6B7BFF] rounded-full transition-all duration-300"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="max-w-4xl w-full mx-auto flex-1 flex flex-col">
        {/* Upper Brand Badge */}
        <div className="text-center mb-6">
          <span className="text-[10px] sm:text-xs font-mono font-bold tracking-[0.4em] text-[#6B7BFF] uppercase">
            SURGING TIDE INTEL SEARCH
          </span>
        </div>

        {/* Input Field Area */}
        <div className="relative border-b-2 border-[#6B7BFF]/40 focus-within:border-[#6B7BFF] pb-4 flex items-center transition-colors">
          <SearchIcon className="w-8 h-8 text-[#6B7BFF] mr-4 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            className="bg-transparent text-xl sm:text-3xl font-sans uppercase font-bold text-[#FFFFFF] placeholder-zinc-700 outline-none w-full tracking-wider"
            placeholder="WHAT ARE YOU SEEKING?"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            id="search-input-field"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-[#C0C0C0] hover:text-[#6B7BFF]"
              id="search-clear-query"
            >
              <X className="w-6 h-6" />
            </button>
          )}
        </div>

        {/* Dynamic Panel */}
        <div className="mt-8 flex-1 overflow-y-auto pb-12 scrollbar-none">
          {!query ? (
            <div className="space-y-8 animate-fade-in">
              <h4 className="text-[#C0C0C0] font-sans font-semibold tracking-widest text-xs uppercase">
                HOT TIDAL DRIFTS
              </h4>
              <div className="flex flex-wrap gap-3">
                {hotSearches.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setQuery(tag)}
                    className="px-4 py-2 bg-[#0D0D1A] rounded-lg border border-[#6B7BFF]/20 hover:border-[#6B7BFF] text-xs font-sans font-bold tracking-widest text-[#C0C0C0] hover:text-[#6B7BFF] transition-all cursor-pointer"
                  >
                    {tag}
                  </button>
                ))}
              </div>
              <div className="p-6 bg-[#0D0D1A] border border-[#6B7BFF]/10 rounded-xl space-y-2">
                <p className="text-[#6B7BFF] text-xs font-mono">EST. 2026 GENERAL ACCESS</p>
                <p className="text-zinc-400 text-xs font-sans leading-relaxed">
                  Type any category or fabric signature (e.g., Heavyweight Knit, 520GSM, Japanese Raw-Indigo) to instantly fetch drop specifications.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <span className="text-zinc-500 font-mono text-xs uppercase">
                  MATCHING CHRONICLES ({results.length})
                </span>
              </div>

              {results.length === 0 ? (
                <div className="py-12 text-center text-zinc-600 font-sans tracking-wide uppercase">
                  NO RESULTS FOUND FOR "{query.toUpperCase()}"
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {results.map((product) => (
                    <div
                      key={product.id}
                      onClick={() => {
                        onNavigateToProduct(product.id);
                        onClose();
                      }}
                      className="group flex p-3 bg-[#0D0D1A] border border-[#6B7BFF]/10 hover:border-[#6B7BFF]/40 rounded-xl cursor-pointer transition-all duration-300"
                    >
                      <div className="w-16 h-16 rounded-lg overflow-hidden bg-black shrink-0 relative border border-zinc-800">
                        <img
                          src={product.primaryImage}
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="ml-4 flex-1 flex flex-col justify-between">
                        <div>
                          <p className="text-[10px] font-mono text-[#6B7BFF] uppercase tracking-wider">
                            {product.category}
                          </p>
                          <h4 className="text-sm font-sans font-bold text-[#E8E8E8] group-hover:text-[#6B7BFF] transition-colors leading-tight tracking-wide">
                            {product.name}
                          </h4>
                        </div>
                        <div className="flex justify-between items-center mt-1">
                          <span className="text-xs font-mono font-bold text-[#C0C0C0]">
                            ${product.price} USD
                          </span>
                          <span className="text-[10px] font-mono text-zinc-600 flex items-center group-hover:text-[#6B7BFF] transition-colors">
                            VIEW DETAILS <ArrowRight className="w-3 h-3 ml-1" />
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
