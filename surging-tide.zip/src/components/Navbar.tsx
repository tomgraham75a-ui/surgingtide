import React, { useState, useEffect } from 'react';
import { Search, Heart, ShoppingBag, Menu, X, ChevronDown } from 'lucide-react';
import Logo from './Logo';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenSearch: () => void;
  onOpenCart: () => void;
  cartCount: number;
  wishlistCount: number;
}

export default function Navbar({
  currentView,
  onNavigate,
  onOpenSearch,
  onOpenCart,
  cartCount,
  wishlistCount,
}: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCollectionsDropdownOpen, setIsCollectionsDropdownOpen] = useState(false);

  // Monitor Scroll coordinates
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'SHOP', view: 'shop' },
    { label: 'LOOKBOOK', view: 'lookbook' },
    { label: 'BLOG', view: 'blog' },
    { label: 'ABOUT', view: 'about' },
    { label: 'CONTACT', view: 'contact' },
  ];

  const categories = [
    { label: 'HOODIES', view: 'collections-hoodies' },
    { label: 'TEES', view: 'collections-tees' },
    { label: 'JEANS', view: 'collections-jeans' },
  ];

  const handleLinkClick = (view: string) => {
    onNavigate(view);
    setIsMobileMenuOpen(false);
    setIsCollectionsDropdownOpen(false);
  };

  return (
    <header
      id="main-app-header"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 select-none ${
        isScrolled
          ? 'bg-[#000000]/95 border-b border-[#6B7BFF]/10 py-3 shadow-[0_4px_30px_rgba(0,0,0,0.8)] backdrop-blur-md'
          : 'bg-transparent py-5'
      }`}
    >
      {/* Decorative metal highlight line */}
      <div className={`absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#6B7BFF]/10 to-transparent ${isScrolled ? 'opacity-100' : 'opacity-0'}`} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 flex justify-between items-center">
        {/* LEFT / LOGO BRAND BLOCK */}
        <div
          onClick={() => handleLinkClick('/')}
          className="flex items-center space-x-3 cursor-pointer group shrink-0"
          id="nav-logo-badge"
        >
          {/* Logo element representation */}
          <Logo iconOnly size="sm"/>
          <div className="text-left font-sans select-none hidden md:block">
            <span className="block text-[11px] font-black tracking-[0.3em] text-[#E8E8E8] group-hover:text-[#6B7BFF] transition-colors leading-none">
              SURGING TIDE
            </span>
            <span className="block text-[8px] font-mono tracking-[0.2em] text-[#C0C0C0] opacity-80 leading-none mt-0.5">
              EST. 2026
            </span>
          </div>
        </div>

        {/* MIDDLE / DESKTOP NAVIGATION PANEL */}
        <nav className="hidden lg:flex items-center space-x-8 text-xs font-sans font-bold tracking-[0.2em]">
          
          <button
            onClick={() => handleLinkClick('shop')}
            className={`text-zinc-300 hover:text-[#6B7BFF] transition-colors relative py-2 cursor-pointer ${
              currentView === 'shop' ? 'text-[#6B7BFF]' : ''
            }`}
          >
            <span>SHOP</span>
            <span className={`absolute bottom-0 left-0 h-[2px] bg-[#6B7BFF] transition-all duration-300 ${currentView === 'shop' ? 'w-full' : 'w-0 hover:w-full'}`} />
          </button>

          {/* Collections Dropdown Link */}
          <div className="relative group">
            <button
              onClick={() => setIsCollectionsDropdownOpen(!isCollectionsDropdownOpen)}
              className="text-zinc-300 hover:text-[#6B7BFF] transition-colors py-2 flex items-center space-x-1 uppercase cursor-pointer"
            >
              <span>COLLECTIONS</span>
              <ChevronDown className="w-3 h-3 group-hover:rotate-180 transition-transform" />
            </button>

            {/* Float Dropdown options */}
            <div className="absolute top-8 left-1/2 -translate-x-1/2 w-48 bg-black border border-[#C0C0C0]/15 p-2 rounded-none shadow-2xl backdrop-blur-md opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity duration-200">
              {categories.map((cat) => (
                <button
                  key={cat.view}
                  onClick={() => handleLinkClick(cat.view)}
                  className="w-full text-left px-4 py-2 hover:bg-[#6B7BFF]/10 text-[10px] font-mono tracking-widest text-[#C0C0C0] hover:text-[#6B7BFF] rounded-none transition-colors cursor-pointer block uppercase"
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {navLinks.map((link) => (
            <button
              key={link.view}
              onClick={() => handleLinkClick(link.view)}
              className={`text-zinc-300 hover:text-[#6B7BFF] transition-colors relative py-2 cursor-pointer uppercase ${
                currentView === link.view ? 'text-[#6B7BFF]' : ''
              }`}
            >
              <span>{link.label}</span>
              <span className={`absolute bottom-0 left-0 h-[2px] bg-[#6B7BFF] transition-all duration-300 ${currentView === link.view ? 'w-full' : 'w-0 hover:w-full'}`} />
            </button>
          ))}
        </nav>

        {/* RIGHT / ACTION TRIGGERS BUTTONS */}
        <div className="flex items-center space-x-2 sm:space-x-4">
          
          {/* 1. Search overlay trigger */}
          <button
            onClick={onOpenSearch}
            className="p-2 sm:p-2.5 text-zinc-400 hover:text-[#6B7BFF] hover:bg-[#6B7BFF]/5 rounded-none border border-transparent hover:border-[#C0C0C0]/15 transition-all cursor-pointer"
            title="Search"
            id="nav-search-trigger"
          >
            <Search className="w-4 sm:w-5 h-4 sm:h-5" />
          </button>

          {/* 2. Wishlist Trigger */}
          <button
            onClick={() => handleLinkClick('wishlist')}
            className={`p-2 sm:p-2.5 hover:bg-[#6B7BFF]/5 rounded-none border border-transparent hover:border-[#C0C0C0]/15 transition-all cursor-pointer relative ${
              currentView === 'wishlist' ? 'text-[#6B7BFF]' : 'text-zinc-400 hover:text-[#6B7BFF]'
            }`}
            title="Wishlist"
            id="nav-wishlist-trigger"
          >
            <Heart className="w-4 sm:w-5 h-4 sm:h-5" />
            {wishlistCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#6B7BFF] text-white text-[9px] font-mono font-bold rounded-none flex items-center justify-center animate-pulse">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* 3. Cart Trigger with floating badge count */}
          <button
            onClick={onOpenCart}
            className="p-2 sm:p-2.5 text-zinc-400 hover:text-[#6B7BFF] hover:bg-[#6B7BFF]/5 rounded-none border border-transparent hover:border-[#C0C0C0]/15 transition-all cursor-pointer relative"
            title="Bag"
            id="nav-cart-trigger"
          >
            <ShoppingBag className="w-4 sm:w-5 h-4 sm:h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#6B7BFF] text-white text-[9px] font-mono font-bold rounded-none flex items-center justify-center animate-pulse">
                {cartCount}
              </span>
            )}
          </button>

          {/* 4. HAMBURGER ICON FOR MOBILE */}
          <button
            onClick={() => setIsMobileMenuOpen(true)}
            className="lg:hidden p-2 text-zinc-400 hover:text-[#6B7BFF] rounded-none border border-transparent hover:border-[#C0C0C0]/15 transition-all cursor-pointer"
            id="mobile-hamburger-trigger"
          >
            <Menu className="w-5 h-5" />
          </button>

        </div>
      </div>

      {/* FULL SCREEN MOBILE OVERLAY MENU SLIDING FROM RIGHT */}
      <div
        className={`fixed inset-0 bg-black/95 z-50 transition-all duration-300 flex flex-col justify-between ${
          isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full pointer-events-none'
        }`}
        id="mobile-navigation-overlay"
      >
        {/* Menu Close Header */}
        <div className="px-6 py-5 flex justify-between items-center border-b border-zinc-900 bg-[#0a0a0a]">
          <div className="flex items-center space-x-2">
            <span className="text-[20px]">🔱</span>
            <span className="font-mono text-[10px] font-bold text-[#6B7BFF] uppercase tracking-widest">ST MOBILE NODE</span>
          </div>
          <button
            onClick={() => setIsMobileMenuOpen(false)}
            id="mobile-menu-close"
            className="p-2 border border-zinc-800 text-[#C0C0C0] hover:text-[#6B7BFF] rounded-none transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Links Column and structure */}
        <div className="flex-1 px-8 py-10 flex flex-col justify-center space-y-6 text-left overflow-y-auto">
          
          <button
            onClick={() => handleLinkClick('/')}
            className="text-2xl font-sans font-black tracking-widest text-[#E8E8E8] hover:text-[#6B7BFF] transition-colors uppercase cursor-pointer"
          >
            MAIN INDEX
          </button>

          <button
            onClick={() => handleLinkClick('shop')}
            className="text-2xl font-sans font-black tracking-widest text-[#E8E8E8] hover:text-[#6B7BFF] transition-colors uppercase cursor-pointer"
          >
            SHOP APPAREL
          </button>

          {/* Categoric divisions inline */}
          <div className="border-l border-[#6B7BFF]/30 pl-4 py-2 space-y-3">
            <span className="block text-[10px] font-mono tracking-widest text-zinc-600 uppercase">COLLECTION CAPSULES</span>
            {categories.map((cat) => (
              <button
                key={cat.view}
                onClick={() => handleLinkClick(cat.view)}
                className="block text-sm font-sans font-black tracking-widest text-[#C0C0C0] hover:text-[#6B7BFF] uppercase cursor-pointer"
              >
                {cat.label}
              </button>
            ))}
          </div>

          {navLinks.map((link) => (
            <button
              key={link.view}
              onClick={() => handleLinkClick(link.view)}
              className="text-2xl font-sans font-black tracking-widest text-[#E8E8E8] hover:text-[#6B7BFF] transition-colors uppercase cursor-pointer text-left"
            >
              {link.label}
            </button>
          ))}

        </div>

        {/* Footer info in overlay */}
        <div className="p-8 border-t border-zinc-900 bg-[#0a0a0a] text-center space-y-2">
          <p className="text-[10px] font-mono tracking-wider text-zinc-600 uppercase">SURGING TIDE BRAND EST. 2026</p>
          <p className="text-[9px] font-mono text-zinc-700 uppercase">SUPPORT@SURGINGTIDE.COM</p>
        </div>

      </div>
    </header>
  );
}
