import React, { useState, useEffect } from 'react';
import { ThumbsUp, Check, Users } from 'lucide-react';
import { VoteItem } from '../types';
import { INITIAL_VOTING } from '../data';

interface VotingSectionProps {
  onAddToast: (type: 'success' | 'info' | 'error' | 'wishlist', text: string) => void;
}

export default function VotingSection({ onAddToast }: VotingSectionProps) {
  const [votables, setVotables] = useState<VoteItem[]>([]);

  // Load and sync vote records from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('surging_votes');
    if (stored) {
      try {
        setVotables(JSON.parse(stored));
      } catch (err) {
        setVotables(INITIAL_VOTING);
      }
    } else {
      setVotables(INITIAL_VOTING);
    }
  }, []);

  const saveVotables = (updated: VoteItem[]) => {
    setVotables(updated);
    localStorage.setItem('surging_votes', JSON.stringify(updated));
  };

  const handleVote = (id: string) => {
    const updated = votables.map((item) => {
      if (item.id === id) {
        if (item.voted) {
          onAddToast('info', 'DEPLANTED VOTE REVOCATION');
          return { ...item, votes: item.votes - 1, voted: false };
        } else {
          onAddToast('success', 'YOUR COMMUNITY DESIGN VOTE COMMITTED');
          return { ...item, votes: item.votes + 1, voted: true };
        }
      }
      return item;
    });
    saveVotables(updated);
  };

  // Compute percentage representations dynamically.
  const totalVotes = votables.reduce((acc, curr) => acc + curr.votes, 0);

  const parsedVotables = votables.map((item) => {
    const pct = totalVotes > 0 ? Math.round((item.votes / totalVotes) * 100) : 0;
    return { ...item, percentage: pct };
  });

  return (
    <section className="py-24 px-6 bg-[#0a0a0a] text-[#E8E8E8] relative select-none w-full" id="community-voting-block">
      {/* Decorative vertical lines and background watermark */}
      <div className="absolute top-0 bottom-0 left-10 w-[1px] bg-zinc-950/20 hidden md:block" />
      <div className="absolute top-0 bottom-0 right-10 w-[1px] bg-zinc-950/20 hidden md:block" />

      <div className="max-w-6xl mx-auto space-y-12 relative z-10 text-center md:text-left">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-zinc-900 pb-8">
          <div>
            <span className="text-[10px] font-mono tracking-[0.4em] text-[#6B7BFF] uppercase block font-bold mb-2">
              EST. 2026 COMMUNITY DEMOCRACY
            </span>
            <h2 className="text-3xl sm:text-5xl font-sans font-black tracking-widest text-[#FFFFFF] uppercase">
              DECIDE THE NEXT DROP
            </h2>
            <p className="text-zinc-500 font-sans text-xs sm:text-sm uppercase tracking-wide mt-2 max-w-xl leading-relaxed">
              VOTE FOR THE APPAREL CONCEPT YOU WANT LAUNCHED IN DROP 05. COMPOSITIONS SECURE VINTAGE STATUS. THE HIGHEST COMMIT SHIPS NEXT MONTH.
            </p>
          </div>

          <div className="flex items-center space-x-3 bg-black px-4 py-3 border border-[#C0C0C0]/15 rounded-none shrink-0 self-center md:self-auto">
            <Users className="w-5 h-5 text-[#6B7BFF]" />
            <div>
              <span className="block text-[8px] font-mono text-zinc-500 uppercase tracking-widest">TOTAL REGISTERED VOTES</span>
              <span className="font-mono text-base font-black text-white">{totalVotes.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Voting Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {parsedVotables.map((item) => (
            <div
              key={item.id}
              className={`bg-black border rounded-none overflow-hidden flex flex-col justify-between group transition-all duration-300 ${
                item.voted
                  ? 'border-[#6B7BFF] shadow-[0_0_20px_rgba(107,123,255,0.15)]'
                  : 'border-[#C0C0C0]/10 hover:border-[#6B7BFF]'
              }`}
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-zinc-950">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                
                {/* Overlay details indicator */}
                <span className="absolute bottom-3 left-3 bg-black border border-zinc-800 px-2.5 py-1 rounded-none text-[8px] font-mono font-bold text-zinc-400">
                  DESIGN SEED #{item.id.toUpperCase()}
                </span>
                
                {item.voted && (
                  <span className="absolute top-3 right-3 bg-[#6B7BFF] text-white px-3 py-1.5 rounded-none text-[9px] font-mono tracking-widest uppercase font-black flex items-center shadow-lg">
                    <Check className="w-3.5 h-3.5 mr-1" /> VOTE CAST
                  </span>
                )}
              </div>

              {/* CARD DETAILS */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-1.5 text-left">
                  <h4 className="text-sm font-sans font-black tracking-widest text-white uppercase line-clamp-1 leading-snug">
                    {item.name}
                  </h4>
                  <p className="text-[10px] text-zinc-500 font-sans tracking-wide leading-relaxed uppercase">
                    {item.description}
                  </p>
                </div>

                {/* Progress Liquid fill calculation */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-end text-[10px] font-mono text-zinc-400 tracking-wider">
                    <span className="uppercase">VOTING TALLY</span>
                    <span className="font-bold text-[#6B7BFF]">{item.votes.toLocaleString()} ({item.percentage}%)</span>
                  </div>
                  
                  {/* Outer bar representing container */}
                  <div className="h-2 w-full bg-black border border-zinc-900 rounded-none overflow-hidden relative">
                    <div
                      className="h-full bg-gradient-to-r from-[#6B7BFF] to-[#A5B4FC] rounded-none transition-all duration-1000 relative"
                      style={{ width: `${item.percentage}%` }}
                    >
                      {/* Wave liquid ripple highlight overlays inside progress */}
                      <span className="absolute inset-0 bg-[linear-gradient(90deg,transparent_0%,rgba(255,255,255,0.4)_50%,transparent_100%)] animate-[pulse_2s_infinite] w-full" />
                    </div>
                  </div>
                </div>

                {/* Interactive ballot triggers */}
                <button
                  onClick={() => handleVote(item.id)}
                  id={`ballot-trigger-${item.id}`}
                  className={`w-full py-2.5 h-10 rounded-none text-[10px] sm:text-xs font-sans font-black tracking-widest uppercase transition-all flex items-center justify-center space-x-2 cursor-pointer ${
                    item.voted
                      ? 'bg-zinc-800 text-[#C0C0C0] hover:bg-rose-950/20 hover:text-rose-400 hover:border hover:border-rose-500/20'
                      : 'bg-[#6B7BFF] text-white hover:bg-[#5B6BEF] shadow-lg shadow-[#6B7BFF]/10'
                  }`}
                >
                  <ThumbsUp className="w-3.5 h-3.5" />
                  <span>{item.voted ? 'REVOKE VOTE' : 'LOCK IN DESIGN'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
