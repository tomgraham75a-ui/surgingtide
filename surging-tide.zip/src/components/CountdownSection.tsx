import React, { useState, useEffect } from 'react';
import { Mail, BellRing, Sparkles } from 'lucide-react';

interface CountdownSectionProps {
  onAddToast: (type: 'success' | 'info' | 'error' | 'wishlist', text: string) => void;
}

export default function CountdownSection({ onAddToast }: CountdownSectionProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 4,
    hours: 12,
    minutes: 48,
    seconds: 30,
  });

  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  // Countdown clock simulation down to next drop!
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        } else {
          // Reset simulated cycle
          return { days: 5, hours: 0, minutes: 0, seconds: 0 };
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      onAddToast('error', 'INVALID EMAIL LINK');
      return;
    }
    setSubscribed(true);
    onAddToast('success', 'EARLY DEPLOYMENT ACCESS UNLOCKED');
    setEmail('');
  };

  // Calculates a rotating percentage for the dynamic glowing ring (simulated mapping against a 7-day cycle)
  const totalSecondsInWeek = 7 * 24 * 60 * 60;
  const currentRemainingSeconds =
    timeLeft.days * 24 * 60 * 60 + timeLeft.hours * 60 * 60 + timeLeft.minutes * 60 + timeLeft.seconds;
  const percentageCompleted = ((totalSecondsInWeek - currentRemainingSeconds) / totalSecondsInWeek) * 100;

  // SVG circular properties
  const radius = 80;
  const stroke = 5;
  const normalizedRadius = radius - stroke * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (percentageCompleted / 100) * circumference;

  return (
    <section className="relative py-24 px-6 bg-[#0a0a0a] border-y border-[#C0C0C0]/10 overflow-hidden select-none w-full">
      {/* Laser backgrounds */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#6B7BFF]/3 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-4xl mx-auto text-center space-y-12 relative z-10">
        
        {/* Glowing Head Team Indicator */}
        <div className="flex flex-col items-center space-y-3">
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 bg-black border border-[#C0C0C0]/15 rounded-none">
            <BellRing className="w-3.5 h-3.5 text-[#6B7BFF] animate-bounce" />
            <span className="text-[10px] font-mono font-bold tracking-[0.3em] text-[#6B7BFF] uppercase">
              NEXT CAPSULE DROP INCOMING
            </span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-sans font-black tracking-[0.15em] text-[#FFFFFF] uppercase">
            DROP 04 // THE HYDRO FORCE
          </h2>
          <p className="text-xs sm:text-sm text-zinc-500 font-sans max-w-lg mx-auto tracking-wide uppercase leading-relaxed">
            SURGING METALLICS, LIQUID WATERFLOW WEAVES, & STRUCTURAL GEOMETRICS. LIMITED CHRONICLES. STAY READY.
          </p>
        </div>

        {/* Digital Halo Glow Ring & Timer */}
        <div className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-16">
          
          {/* Glowing blue ring section */}
          <div className="relative flex items-center justify-center">
            {/* Pulsing visual back ring */}
            <div className="absolute w-[180px] h-[180px] border border-[#6B7BFF]/10 rounded-full animate-ping pointer-events-none" />
            <div className="absolute w-[150px] h-[150px] bg-gradient-to-br from-black to-[#111111] rounded-full border border-zinc-900 shadow-2xl" />
            
            {/* SVG Circular loader */}
            <svg height={180} width={180} className="rotate-[-90deg] relative z-10">
              <circle
                stroke="rgba(107, 123, 255, 0.05)"
                fill="transparent"
                strokeWidth={stroke}
                r={normalizedRadius}
                cx={90}
                cy={90}
              />
              <circle
                stroke="#6B7BFF"
                fill="transparent"
                strokeWidth={stroke}
                strokeDasharray={circumference + ' ' + circumference}
                style={{ strokeDashoffset }}
                strokeLinecap="round"
                r={normalizedRadius}
                cx={90}
                cy={90}
                className="drop-shadow-[0_0_8px_rgba(107,123,255,0.7)]"
              />
            </svg>

            {/* Middle Logo Icon overlay inside circle */}
            <div className="absolute z-20 flex flex-col items-center justify-center">
              <span className="text-[20px] filter drop-shadow-[0_0_8px_rgba(107,123,255,0.6)]">🔱</span>
              <span className="font-mono text-[9px] font-black text-white tracking-widest uppercase mt-1">ST2026</span>
            </div>
          </div>

          {/* Dials Block Grid */}
          <div className="grid grid-cols-4 gap-3 sm:gap-6">
            {[
              { label: 'DAYS', value: timeLeft.days },
              { label: 'HOURS', value: timeLeft.hours },
              { label: 'MINUTES', value: timeLeft.minutes },
              { label: 'SECONDS', value: timeLeft.seconds },
            ].map((d, index) => (
              <div
                key={index}
                className="w-18 sm:w-24 p-2 sm:p-4 bg-black border border-[#C0C0C0]/10 hover:border-[#6B7BFF] rounded-none flex flex-col justify-center items-center relative transition-all duration-300 shadow-[0_0_15px_rgba(0,0,0,0.6)]"
              >
                {/* Visual grid texture overlay */}
                <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-[#6B7BFF]/30" />
                <span className="text-2xl sm:text-4xl font-mono font-black text-[#6B7BFF] drop-shadow-[0_0_10px_rgba(107,123,255,0.5)]">
                  {String(d.value).padStart(2, '0')}
                </span>
                <span className="text-[8px] sm:text-[9px] font-mono tracking-widest text-zinc-500 font-bold mt-1 uppercase">
                  {d.label}
                </span>
              </div>
            ))}
          </div>

        </div>

        {/* Email Subscription forms */}
        <div className="max-w-md mx-auto bg-black border border-[#C0C0C0]/10 p-6 sm:p-8 rounded-none">
          {!subscribed ? (
            <form onSubmit={handleSubscribe} className="space-y-4">
              <div className="text-left">
                <h4 className="text-[11px] font-mono font-bold tracking-[0.2em] text-[#C0C0C0] uppercase">
                  ACQUIRE EARLY TRANSMISSION KEYS
                </h4>
                <p className="text-[10px] text-zinc-500 font-sans tracking-wide uppercase mt-1">
                  ENTER AN EMAIL ADDRESS TO UNLOCK ACCESS CURATOR SECTOR 24 HOURS BEFORE ST-04 DEPLOYMENT.
                </p>
              </div>

              <div className="relative flex items-center bg-black rounded-none border border-[#C0C0C0]/15 focus-within:border-[#6B7BFF] overflow-hidden transition-all">
                <div className="pl-3 py-3 text-zinc-500 shrink-0">
                  <Mail className="w-4 h-4 text-[#6B7BFF]/70" />
                </div>
                <input
                  type="email"
                  required
                  placeholder="YOU@COMMUNICATION.COM"
                  className="bg-transparent pl-2 pr-3 py-3 text-xs font-mono tracking-widest text-white outline-none w-full uppercase placeholder-zinc-700"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  id="countdown-subscribe-email"
                />
                <button
                  type="submit"
                  id="countdown-subscribe-button"
                  className="px-4 bg-[#6B7BFF] hover:bg-[#5B6BEF] text-white text-[10px] sm:text-xs font-sans font-black tracking-widest uppercase h-full self-stretch select-none transition-all cursor-pointer whitespace-nowrap rounded-none"
                >
                  DEFER REGISTRATION
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-3 py-4 text-center animate-fade-in">
              <div className="inline-flex w-10 h-10 rounded-full border border-emerald-500/20 bg-emerald-500/5 items-center justify-center p-1">
                <Sparkles className="w-5 h-5 text-emerald-400" />
              </div>
              <h5 className="font-sans font-bold text-xs tracking-widest text-[#E8E8E8] uppercase">
                KEYS GRANTED // CODES SECURED
              </h5>
              <p className="text-[10px] text-zinc-500 font-sans uppercase max-w-xs mx-auto leading-normal">
                An auth invite packet has been queued. When the tide rises, you will receive your credentials.
              </p>
            </div>
          )}
        </div>

      </div>
    </section>
  );
}
