import React, { useState } from 'react';
import { X, ShoppingBag, Plus, Minus, Trash2, ShieldCheck, ArrowRight, CreditCard, Sparkles } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, newQty: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  onAddToast: (type: 'success' | 'info' | 'error' | 'wishlist', text: string) => void;
}

type CheckoutStep = 'cart' | 'shipping' | 'payment' | 'completed';

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onAddToast,
}: CartDrawerProps) {
  const [step, setStep] = useState<CheckoutStep>('cart');
  
  // Checkout Form states
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [zip, setZip] = useState('');
  const [cardNo, setCardNo] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const shippingCost = subtotal > 150 ? 0 : 15;
  const total = subtotal + shippingCost;

  const handleStartCheckout = () => {
    if (cartItems.length === 0) {
      onAddToast('error', 'YOUR CART IS EMPTY');
      return;
    }
    setStep('shipping');
  };

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !fullName || !address || !city || !zip) {
      onAddToast('error', 'ALL FIELDS ARE MANDATORY');
      return;
    }
    setStep('payment');
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cardNo || !cardExpiry || !cardCvv) {
      onAddToast('error', 'INPUT YOUR PAYMENT METADATA');
      return;
    }
    onAddToast('success', 'SURGING TRANSACTION SECURED');
    setStep('completed');
  };

  const handleCloseSuccess = () => {
    onClearCart();
    setStep('cart');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden select-none" id="cart-drawer-root">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={step === 'completed' ? handleCloseSuccess : onClose}
      />

      <div className="absolute inset-y-0 right-0 max-w-full flex">
        <div className="w-screen max-w-md bg-[#05050A] border-l border-[#6B7BFF]/20 flex flex-col shadow-2xl relative">
          
          {/* Wave Grid Aesthetic Line overlay top */}
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-[#6B7BFF] to-[#5B6BEF]" />

          {/* Drawer Header */}
          <div className="px-6 py-5 border-b border-[#6B7BFF]/10 flex justify-between items-center bg-[#090912]">
            <div className="flex items-center space-x-2">
              <ShoppingBag className="w-5 h-5 text-[#6B7BFF]" />
              <span className="font-sans font-bold text-sm tracking-[0.3em] text-[#E8E8E8] uppercase">
                {step === 'cart' && 'YOUR HARVEST'}
                {step === 'shipping' && 'VESSEL DEBARKATION'}
                {step === 'payment' && 'SECURE TRANSMISSION'}
                {step === 'completed' && 'SURGE COMPLETED'}
              </span>
            </div>
            <button
              onClick={step === 'completed' ? handleCloseSuccess : onClose}
              className="text-[#C0C0C0] hover:text-[#6B7BFF] transition-colors p-2 rounded-full border border-zinc-800 hover:border-[#6B7BFF]"
              id="close-cart-drawer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* STEP 1: CART HARVEST LIST */}
          {step === 'cart' && (
            <div className="flex-1 flex flex-col justify-between overflow-hidden">
              <div className="flex-1 overflow-y-auto px-6 py-4 scrollbar-none space-y-4">
                {cartItems.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-24">
                    <div className="w-16 h-16 rounded-full border border-[#6B7BFF]/20 flex items-center justify-center bg-[#0D0D1A]">
                      <ShoppingBag className="w-6 h-6 text-[#6B7BFF] opacity-40" />
                    </div>
                    <div>
                      <p className="font-mono text-xs text-[#C0C0C0] tracking-widest uppercase">THE DEEP IS VACANT</p>
                      <p className="text-zinc-600 text-[11px] mt-1 uppercase">YOUR BAG IS CURRENTLY EMPTY</p>
                    </div>
                    <button
                      onClick={onClose}
                      className="mt-4 px-4 py-2 border border-[#6B7BFF] hover:bg-[#6B7BFF]/10 text-xs text-[#6B7BFF] rounded-lg tracking-widest font-mono uppercase transition-all"
                    >
                      EXPLORE APPAREL
                    </button>
                  </div>
                ) : (
                  cartItems.map((item) => (
                    <div
                      key={item.id}
                      className="flex bg-[#0D0D1A] border border-[#6B7BFF]/10 hover:border-[#6B7BFF]/30 p-3 rounded-xl transition-all"
                    >
                      <div className="w-16 h-16 rounded-lg bg-black overflow-hidden shrink-0 border border-zinc-800">
                        <img
                          src={item.product.primaryImage}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="ml-4 flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between">
                            <h4 className="text-[11px] font-sans font-bold text-[#E8E8E8] tracking-widest uppercase">
                              {item.product.name}
                            </h4>
                            <button
                              onClick={() => {
                                onRemoveItem(item.id);
                                onAddToast('info', 'REMOVED ITEM');
                              }}
                              className="text-zinc-600 hover:text-rose-500 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                          <p className="text-[10px] text-zinc-500 font-mono tracking-wider mt-1 uppercase">
                            COLOUR: {item.selectedColor} | SIZE: {item.selectedSize}
                          </p>
                        </div>
                        <div className="flex justify-between items-center mt-2">
                          <div className="flex items-center space-x-1 border border-[#6B7BFF]/20 rounded bg-black/60">
                            <button
                              onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                              className="px-2 py-1 text-zinc-500 hover:text-[#6B7BFF] font-mono text-sm"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 font-mono text-xs text-[#E8E8E8]">{item.quantity}</span>
                            <button
                              onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                              className="px-2 py-1 text-zinc-500 hover:text-[#6B7BFF] font-mono text-sm"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                          <span className="font-mono text-xs font-bold text-[#6B7BFF]">
                            ${item.product.price * item.quantity} USD
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {cartItems.length > 0 && (
                <div className="p-6 bg-[#090912] border-t border-[#6B7BFF]/10 space-y-4">
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs text-zinc-500 uppercase tracking-widest">
                      <span>HARVEST SUB</span>
                      <span className="font-mono font-bold text-[#E8E8E8]">${subtotal} USD</span>
                    </div>
                    <div className="flex justify-between text-xs text-zinc-500 uppercase tracking-widest">
                      <span>VESSEL SHIPMENT</span>
                      <span className="font-mono font-bold text-[#E8E8E8]">
                        {shippingCost === 0 ? 'FREE' : `$${shippingCost} USD`}
                      </span>
                    </div>
                    <div className="border-t border-[#6B7BFF]/15 my-2 pt-2 flex justify-between text-xs text-[#6B7BFF] font-bold uppercase tracking-[0.2em]">
                      <span>TOTAL DUE</span>
                      <span className="font-mono text-sm font-black">${total} USD</span>
                    </div>
                  </div>
                  <button
                    onClick={handleStartCheckout}
                    className="w-full h-12 bg-gradient-to-r from-[#6B7BFF] to-[#5B6BEF] text-white hover:opacity-90 rounded-lg flex items-center justify-center font-sans font-bold tracking-[0.3em] text-xs uppercase cursor-pointer shadow-[0_0_15px_rgba(107,123,255,0.25)] group transition-all"
                  >
                    PROCEED TO WAVE DESPATCH <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* STEP 2: SHIPPING DETAILS */}
          {step === 'shipping' && (
            <form onSubmit={handleShippingSubmit} className="flex-1 flex flex-col justify-between overflow-hidden">
              <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4 scrollbar-none text-left">
                <p className="text-[10px] font-mono text-[#6B7BFF] uppercase tracking-widest mb-2">
                  SECURE SHIPPING NODE DESTINATION
                </p>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase mb-1">
                      COMMUNICATION LINK (EMAIL)
                    </label>
                    <input
                      type="email"
                      required
                      className="w-full h-10 px-3 bg-[#0D0D1A] border border-[#6B7BFF]/20 focus:border-[#6B7BFF] rounded-lg text-xs text-[#E8E8E8] placeholder-zinc-700 outline-none uppercase font-mono tracking-widest"
                      placeholder="YOU@COMMUNICATION.COM"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase mb-1">
                      CITIZEN NAME (FULL NAME)
                    </label>
                    <input
                      type="text"
                      required
                      className="w-full h-10 px-3 bg-[#0D0D1A] border border-[#6B7BFF]/20 focus:border-[#6B7BFF] rounded-lg text-xs text-[#E8E8E8] placeholder-zinc-700 outline-none uppercase font-mono tracking-widest"
                      placeholder="FIRST AND LAST"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase mb-1">
                      STREET SECTOR (ADDRESS)
                    </label>
                    <input
                      type="text"
                      required
                      className="w-full h-10 px-3 bg-[#0D0D1A] border border-[#6B7BFF]/20 focus:border-[#6B7BFF] rounded-lg text-xs text-[#E8E8E8] placeholder-zinc-700 outline-none uppercase font-mono tracking-widest"
                      placeholder="101 APPAREL HARBOR WY"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase mb-1">
                        METROPOLIS (CITY)
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full h-10 px-3 bg-[#0D0D1A] border border-[#6B7BFF]/20 focus:border-[#6B7BFF] rounded-lg text-xs text-[#E8E8E8] placeholder-zinc-700 outline-none uppercase font-mono tracking-widest"
                        placeholder="LOS ANGELES"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase mb-1">
                        ZONE DEED (ZIP)
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full h-10 px-3 bg-[#0D0D1A] border border-[#6B7BFF]/20 focus:border-[#6B7BFF] rounded-lg text-xs text-[#E8E8E8] placeholder-zinc-700 outline-none uppercase font-mono tracking-widest"
                        placeholder="90210"
                        value={zip}
                        onChange={(e) => setZip(e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-[#090912]/80 border border-zinc-900 rounded-xl p-4 mt-6">
                  <span className="text-[10px] font-mono text-zinc-500 flex items-center uppercase">
                    <ShieldCheck className="w-4 h-4 text-[#6B7BFF] mr-2" /> TOTAL SECURITY ASSURED
                  </span>
                  <p className="text-[9px] text-zinc-600 mt-1 uppercase leading-normal">
                    DATA PRESERVED SECURELY WITH PITCH-BLACK AES CONSTRAINTS. SHIPPING WILL EMIT AN AUTO-TRIGGER CODE ON DRIFT DISPATCH.
                  </p>
                </div>
              </div>

              <div className="p-6 bg-[#090912] border-t border-[#6B7BFF]/10 flex space-x-3">
                <button
                  type="button"
                  onClick={() => setStep('cart')}
                  className="flex-1 h-12 border border-zinc-800 hover:border-zinc-700 text-[#C0C0C0] rounded-lg text-xs font-mono uppercase tracking-widest transition-all cursor-pointer"
                >
                  BACK TO BAG
                </button>
                <button
                  type="submit"
                  className="flex-1 h-12 bg-[#6B7BFF] text-white hover:opacity-90 rounded-lg text-xs font-sans font-bold tracking-[0.2em] uppercase transition-all cursor-pointer flex items-center justify-center shadow-lg"
                >
                  NEXT: CREDIT LINK
                </button>
              </div>
            </form>
          )}

          {/* STEP 3: SIMULATED PAYMENT */}
          {step === 'payment' && (
            <form onSubmit={handlePaymentSubmit} className="flex-1 flex flex-col justify-between overflow-hidden">
              <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4 scrollbar-none text-left">
                <p className="text-[10px] font-mono text-[#6B7BFF] uppercase tracking-widest mb-1">
                  TRANSACTION DESTRUCT LINK
                </p>

                {/* Silver metallic Credit Card rendering */}
                <div className="border border-zinc-800 rounded-xl p-5 bg-gradient-to-br from-zinc-900 to-black relative overflow-hidden shadow-xl mb-4">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-[#6B7BFF]/5 rounded-full blur-2xl" />
                  <div className="flex justify-between items-start">
                    <div className="text-zinc-600 font-mono text-[9px] tracking-widest uppercase">
                      SURGING CORE CARD
                    </div>
                    <CreditCard className="w-6 h-6 text-[#C0C0C0]" />
                  </div>
                  
                  <p className="text-xs sm:text-sm font-mono tracking-widest text-white mt-8 uppercase">
                    {cardNo || '•••• •••• •••• ••••'}
                  </p>

                  <div className="flex justify-between items-end mt-4">
                    <div>
                      <span className="block text-[8px] text-zinc-600 font-mono uppercase tracking-wider">HOLDER</span>
                      <span className="text-[10px] font-mono uppercase text-zinc-300">{fullName || 'CITIZEN'}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] text-zinc-600 font-mono uppercase tracking-wider">EXP</span>
                      <span className="text-[10px] font-mono uppercase text-zinc-300">{cardExpiry || 'MM/YY'}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase mb-1">
                      CREDIT LINK IDENTIFIER (CARD NUMBER)
                    </label>
                    <input
                      type="text"
                      required
                      className="w-full h-10 px-3 bg-[#0D0D1A] border border-[#6B7BFF]/20 focus:border-[#6B7BFF] rounded-lg text-xs text-[#E8E8E8] placeholder-zinc-700 outline-none uppercase font-mono tracking-widest"
                      placeholder="16 DIGITS LINK COFFEE"
                      value={cardNo}
                      maxLength={19}
                      onChange={(e) => setCardNo(e.target.value)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase mb-1">
                        EXPIRY (MM/YY)
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full h-10 px-3 bg-[#0D0D1A] border border-[#6B7BFF]/20 focus:border-[#6B7BFF] rounded-lg text-xs text-[#E8E8E8] placeholder-zinc-700 outline-none uppercase font-mono tracking-widest"
                        placeholder="12/28"
                        maxLength={5}
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase mb-1">
                        KEY CODES (CVV)
                      </label>
                      <input
                        type="password"
                        required
                        className="w-full h-10 px-3 bg-[#0D0D1A] border border-[#6B7BFF]/20 focus:border-[#6B7BFF] rounded-lg text-xs text-[#E8E8E8] placeholder-zinc-700 outline-none uppercase font-mono tracking-widest"
                        placeholder="3 DIGITS"
                        maxLength={3}
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 bg-[#090912] border-t border-[#6B7BFF]/10 flex space-x-3">
                <button
                  type="button"
                  onClick={() => setStep('shipping')}
                  className="flex-1 h-12 border border-zinc-800 hover:border-zinc-700 text-[#C0C0C0] rounded-lg text-xs font-mono uppercase tracking-widest transition-all cursor-pointer"
                >
                  EDIT ADDR
                </button>
                <button
                  type="submit"
                  className="flex-1 h-12 bg-gradient-to-r from-[#6B7BFF] to-[#5B6BEF] text-white hover:opacity-90 rounded-lg text-xs font-sans font-bold tracking-[0.2em] uppercase transition-all cursor-pointer flex items-center justify-center shadow-lg shadow-[#6B7BFF]/20"
                >
                  SECURE TIDE PAY: ${total}
                </button>
              </div>
            </form>
          )}

          {/* STEP 4: ORDER CONCLUDED SUCCESS */}
          {step === 'completed' && (
            <div className="flex-1 flex flex-col justify-center items-center p-8 space-y-6 text-center text-left">
              <div className="w-20 h-20 rounded-full bg-gradient-to-r from-[#6B7BFF] to-[#dbf3fa]/20 flex items-center justify-center p-3 animate-bounce shadow-[0_0_30px_rgba(107,123,255,0.4)]">
                <Sparkles className="w-10 h-10 text-white" />
              </div>

              <div className="space-y-2 max-w-sm">
                <span className="text-[10px] font-mono tracking-[0.4em] text-[#6B7BFF] uppercase block font-bold">
                  WAVE SECURED EST. 2026
                </span>
                <h3 className="text-xl font-sans font-black tracking-wider text-white uppercase leading-normal">
                  RIDE THE STYLE WAVE DISPATCHED
                </h3>
                <p className="text-xs text-zinc-400 font-sans leading-relaxed uppercase">
                  Thank you, citizen <span className="text-[#6B7BFF] font-bold">{fullName}</span>. Your transactional wave has been compiled as order <span className="text-white font-mono font-bold">#ST-{Math.floor(100000 + Math.random() * 900000)}</span>.
                </p>
              </div>

              <div className="w-full bg-[#0D0D1A] border border-[#6B7BFF]/20 rounded-xl p-4 text-left space-y-3">
                <h5 className="text-[10px] font-mono tracking-widest text-[#C0C0C0] uppercase font-bold">
                  TRANSMISSION METADATA
                </h5>
                <div className="divide-y divide-zinc-900 text-[10px] font-sans">
                  <div className="py-2 flex justify-between text-zinc-500 uppercase">
                    <span>SECTOR TARGET</span>
                    <span className="text-right text-[#E8E8E8]">{address}, {city}</span>
                  </div>
                  <div className="py-2 flex justify-between text-zinc-500 uppercase">
                    <span>TRACKING KEY</span>
                    <span className="text-[#6B7BFF] font-mono">ST-WAVE-TRACK-TRIDENT</span>
                  </div>
                </div>
              </div>

              <button
                onClick={handleCloseSuccess}
                className="w-full h-12 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs font-mono uppercase tracking-[0.3em] transition-all cursor-pointer shadow-md"
              >
                RETURN TO DRIFT
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
