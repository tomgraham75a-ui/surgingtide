import React from 'react';

interface WaveDividerProps {
  className?: string;
  inverse?: boolean;
}

export default function WaveDivider({ className = '', inverse = false }: WaveDividerProps) {
  return (
    <div className={`relative w-full overflow-hidden leading-none z-10 select-none ${className}`}>
      <style>{`
        @keyframes waveshift1 {
          0% { transform: translateX(0px); }
          50% { transform: translateX(-400px); }
          100% { transform: translateX(0px); }
        }
        @keyframes waveshift2 {
          0% { transform: translateX(-300px); }
          50% { transform: translateX(0px); }
          100% { transform: translateX(-300px); }
        }
        .animate-wave-1 {
          animation: waveshift1 25s ease-in-out infinite;
        }
        .animate-wave-2 {
          animation: waveshift2 18s ease-in-out infinite;
        }
      `}</style>

      <svg
        className="w-full h-8 sm:h-12 text-[#6B7BFF]/10"
        viewBox="0 0 1200 120"
        preserveAspectRatio="none"
        xmlns="http://www.w3.org/2000/svg"
        style={{ transform: inverse ? 'rotate(180deg)' : 'none' }}
      >
        {/* Layer 1 - Deep blue wave translucent */}
        <path
          className="animate-wave-1 fill-[#6B7BFF]/10"
          d="M0,60 C150,90 350,30 500,75 C650,110 850,20 1000,70 C1150,110 1300,50 1450,80 L1450,120 L0,120 Z"
          style={{ width: '200%' }}
        />
        {/* Layer 2 - Subtle metal slate wave more translucent */}
        <path
          className="animate-wave-2 fill-[#6B7BFF]/20"
          d="M-300,40 C-150,80 50,20 200,65 C350,100 550,40 700,80 C850,110 1050,30 1200,70 L1200,120 L-300,120 Z"
          style={{ width: '200%' }}
        />
      </svg>
    </div>
  );
}
