import React, { useEffect } from 'react';
import { X, CheckCircle, Info, Heart } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'error' | 'wishlist';
  text: string;
}

interface ToastProps {
  key?: any;
  toast: ToastMessage;
  onClose: (id: string) => void;
}

export default function Toast({ toast, onClose }: ToastProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose(toast.id);
    }, 4000);
    return () => clearTimeout(timer);
  }, [toast, onClose]);

  const icons = {
    success: <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />,
    wishlist: <Heart className="w-5 h-5 text-[#6B7BFF] fill-[#6B7BFF] shrink-0" />,
    info: <Info className="w-5 h-5 text-indigo-400 shrink-0" />,
    error: <X className="w-5 h-5 text-rose-500 shrink-0" />,
  };

  return (
    <div
      id={`toast-${toast.id}`}
      className="flex items-center space-x-3 bg-black border border-[#C0C0C0]/20 hover:border-[#6B7BFF] px-4 py-3 rounded-none shadow-[0_4px_25px_rgba(0,0,0,0.5)] text-[#E8E8E8] backdrop-blur-md pointer-events-auto max-w-sm w-full transition-all duration-300 transform translate-y-0 text-sm animate-fade-in-up"
    >
      <div>{icons[toast.type]}</div>
      <div className="flex-1 font-sans text-xs tracking-wide uppercase">{toast.text}</div>
      <button
        onClick={() => onClose(toast.id)}
        className="text-[#C0C0C0] hover:text-[#6B7BFF] transition-colors p-1"
        id={`toast-close-${toast.id}`}
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
