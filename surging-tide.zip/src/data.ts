import { Product, VoteItem, BlogPost, LookbookItem } from './types';

// Let's reference our custom generated images
export const IMAGES = {
  bgWave: '/src/assets/images/bg_wave_particle_1780239540538.png',
  hoodie: '/src/assets/images/hoodie_product_1780239561914.png',
  tee: '/src/assets/images/tee_product_1780239577771.png',
  jeans: '/src/assets/images/jeans_product_1780239593700.png',
  lookbookModel: '/src/assets/images/lookbook_model_1780239613849.png',
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'ST-01',
    name: 'SURGE METALLIC HOODIE',
    price: 85,
    description: 'A structural, heavyweight knit featuring a raised silver metallic trident logo and dual electric-blue accent lines.',
    longDescription: 'Engineered for absolute form and luxury. The Surge Metallic Hoodie is forged from 520GSM ultra-dense organic cotton fleece. It features custom ribbing, dropped shoulders for a relaxed silhouette, and a high-stance double-layered hood. The centerpiece is our signature silver-metallic trident, heat-fused to withstand the elements, flanked by double-needle flatlock blue stitches.',
    category: 'hoodies',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Midnight Black', 'Metallic Silver'],
    primaryImage: IMAGES.hoodie,
    secondaryImage: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    details: [
      '520GSM 100% Organic Cotton Fleece',
      'High-definition fusion metal trident print',
      'Overlock structural blue stitch detailing',
      'Double-lined heavyweight structured hood',
      'Pre-shrunk for the perfect lifetime fit',
    ],
    reviews: [
      {
        id: 'rev-101',
        author: 'Marcus K.',
        rating: 5,
        comment: 'Absurdly high quality. It feels heavy, structured, and sits exactly like premium streetwear should. The silver logo stands out perfectly.',
        date: '2026-05-12',
        verified: true,
      },
      {
        id: 'rev-102',
        author: 'Zack Y.',
        rating: 5,
        comment: 'The 520GSM fabric is no joke. Kept its structure perfectly after three cold washes. Surging Tide is the real deal.',
        date: '2026-05-18',
        verified: true,
      }
    ],
  },
  {
    id: 'ST-02',
    name: 'TIDAL FORCE GRAPHIC TEE',
    price: 45,
    description: 'Clean, heavy-cut geometric silhouette in washed charcoal with a centered chrome-trident motif.',
    longDescription: 'The perfect foundation for an unapologetic fit. Our Tidal Force Tee is crafted from 280GSM combed ringspun cotton, giving it a stiff, thick build that maintains a vintage geometric drape. It features a high, snug rib neckband and twin-needle stitched hems. The central metallic graphic symbolizes the ultimate rise above the style currents.',
    category: 'tees',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Midnight Black', 'Vintage Gray'],
    primaryImage: IMAGES.tee,
    secondaryImage: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=800',
    rating: 4.8,
    details: [
      '280GSM Combed Ringspun Heavyweight Cotton',
      'Snug 1.25" rib collar prevents stretching',
      'Reflective metallic silver chest print',
      'Extended short sleeves with drop-shoulder cut',
      'Eco-certified waterless ink printing',
    ],
    reviews: [
      {
        id: 'rev-201',
        author: 'Leo G.',
        rating: 5,
        comment: 'Very thick. Hard to find shirts that actually drape like this. Neck collar is nice and tight, won’t stretch out.',
        date: '2026-05-10',
        verified: true,
      }
    ],
  },
  {
    id: 'ST-03',
    name: 'MIDNIGHT STEALTH RELAXED JEANS',
    price: 115,
    description: 'A sharp, relaxed straight-leg denim finished in deep indigo-black with subtle metallic steel rivets.',
    longDescription: 'Re-imagined from the fibers up. We’ve reconstructed standard denim using a custom pre-washed 14.5oz Japanese shuttle-loom denim. Finished in an intense midnight indigo-black shade that ages into a rich silver-faded charcoal, these jeans sit comfortably below the waist with a wider, relaxed thigh and a sharp straight drop.',
    category: 'jeans',
    sizes: ['30', '32', '34', '36'],
    colors: ['Midnight Indigo', 'Deep Obsidian'],
    primaryImage: IMAGES.jeans,
    secondaryImage: 'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&q=80&w=800',
    rating: 4.7,
    details: [
      '14.5oz premium Japanese raw-indigo denim',
      'Steel-reinforced silver customized hardware',
      'Slightly brushed interior for maximum skin comfort',
      'Signature trident embroidery on inner coin-pocket',
      'Reinforced rear pocket backing',
    ],
    reviews: [
      {
        id: 'rev-301',
        author: 'Arthur M.',
        rating: 4,
        comment: 'Outstanding cut. Stiff but shapes nicely to the body. Indigo looks almost black but shifts nicely under spotlight.',
        date: '2026-05-14',
        verified: true,
      }
    ],
  },
  {
    id: 'ST-04',
    name: 'VORTEX DRIFT ZIP HOODIE',
    price: 95,
    description: 'Full double-zip construction styled in jet-black and lined with high-density silver mesh panels.',
    longDescription: 'The pinnacle of tech-clothing outerwear. Designed with custom dual-ended polished hardware for adjustable styling, the Vortex Drift is equipped with hidden side pockets, high-definition piping along the seams, and a subtle reflective logo lining the outer hood.',
    category: 'hoodies',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Midnight Black', 'Glacier Slate'],
    primaryImage: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&q=80&w=800',
    secondaryImage: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    details: [
      '480GSM premium loopback cotton',
      'Polished heavy-duty metal dual track zippers',
      'Reflective logo detail line',
      'Thermal silver-mesh sleeve inserts',
    ],
    reviews: [
      {
        id: 'rev-401',
        author: 'Tyson D.',
        rating: 5,
        comment: 'The double zip is amazing. I style it half open from the bottom. Extremely high tier hoodie.',
        date: '2026-05-20',
        verified: true,
      }
    ],
  },
  {
    id: 'ST-05',
    name: 'TEMPEST HEAVY COTTON TEE',
    price: 48,
    description: 'Rich, deep electric blue graphics exploding on an intense jet obsidian oversized base.',
    longDescription: 'A statement of raw energy. The Tempest Tee features an exclusive fluid graphic reflecting high-speed deep ocean waves crashing against concrete reefs. This premium graphic uses puff-print texture for a true sensory feel.',
    category: 'tees',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Obsidian Black'],
    primaryImage: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=800', // standard clean dark shirt mockup visual
    secondaryImage: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&q=80&w=800',
    rating: 4.6,
    details: [
      '300GSM custom luxury weave cotton',
      'Raised tactile 3D puff print graphic',
      'Thick ribbed collar with flat lock reinforcements',
      'Raw wash finish for soft comfort texture',
    ],
    reviews: [
      {
        id: 'rev-501',
        author: 'Chris L.',
        rating: 4,
        comment: 'Puff print looks and feels incredible. Fits slightly wider than the Tidal Force model.',
        date: '2026-05-24',
        verified: true,
      }
    ],
  },
  {
    id: 'ST-06',
    name: 'WAVE CUT DISTRICT DENIM',
    price: 125,
    description: 'Asymmetric paneled seams mirroring hydrodynamic lines on premium textured charcoal-gray denim.',
    longDescription: 'Designed to rewrite the denim rulebook. The Wave Cut Denim incorporates engineered leg-panels that subtle curve around the knee for natural fluid motion. Standard pockets are updated with slash enclosures, complemented by high-density rivets.',
    category: 'jeans',
    sizes: ['30', '32', '34', '36'],
    colors: ['Charcoal Gray', 'Jet Black'],
    primaryImage: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=800',
    secondaryImage: 'https://images.unsplash.com/photo-1582562124811-c09040d0a901?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    details: [
      '15oz raw Japanese structural denim',
      'Hydromechanical seam panning stitch pattern',
      'Debossed silver hardware accents',
      'Exclusive silver branding patch',
    ],
    reviews: [
      {
        id: 'rev-601',
        author: 'Damon S.',
        rating: 5,
        comment: 'Seaming on the knees is beautiful. Really gives it a unique cyberpunk structural vibe.',
        date: '2026-05-22',
        verified: true,
      }
    ],
  }
];

export const INITIAL_VOTING: VoteItem[] = [
  {
    id: 'vote-01',
    name: 'STORM CORE ANORAK',
    description: 'Technical tactical shell jacket, wind resistant, quick-pull cords, and hyper-reflective silver trident detailing.',
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=800',
    votes: 4324,
    voted: false
  },
  {
    id: 'vote-02',
    name: 'TRIDENT CARGO SYSTEM Pants',
    description: 'Heavy duty modular cargo featuring expandable deep ocean utility pockets, custom buckles, and ankle taper straps.',
    image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&q=80&w=800',
    votes: 3892,
    voted: false
  },
  {
    id: 'vote-03',
    name: 'NEOPRENE CYCLONE SWEATSHIRT',
    description: 'Waterproof double-knit neoprene crewneck with high collar and asymmetric blue zipper lining.',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=800',
    votes: 3105,
    voted: false
  }
];

export const LOOKBOOK_ITEMS: LookbookItem[] = [
  {
    id: 'look-1',
    title: 'THE CORE OF SURGE',
    subtitle: 'Washed charcoal denim paired with the 520GSM signature shield hoodie defines modern geometric presence.',
    image: IMAGES.lookbookModel,
    productName: 'SURGE METALLIC HOODIE',
    productId: 'ST-01',
  },
  {
    id: 'look-2',
    title: 'STRICT GEOMETRIES',
    subtitle: 'Minimal silhouettes meet structural fabrics in extreme lighting.',
    image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&q=80&w=800',
    productName: 'TIDAL FORCE GRAPHIC TEE',
    productId: 'ST-02',
  },
  {
    id: 'look-3',
    title: 'TIDAL MOVEMENTS',
    subtitle: 'Engineered raw steel seams adapt to active urban strides.',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&q=80&w=800',
    productName: 'MIDNIGHT STEALTH RELAXED JEANS',
    productId: 'ST-03',
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-1',
    title: 'RECONSTRUCTING DENIM: THE HYDRODYNAMIC LINE',
    summary: 'A deep look into the structural seam engineering behind the Wave Cut District Denim, launching in Drop 05.',
    content: `Denim has been cut the same way for almost two centuries. Our design floor decided this was unacceptable.\n\nWe looked at mechanical stress mappings and fluid dynamics. By tracing the seams along natural muscle contours and bending coordinates, we completely eliminated restricted knee tension.\n\nThe result is a jeans fit that flows. Using premium 15oz raw Japanese shuttle denim, the garment retains streetwear heft but behaves with unprecedented motion flexibility.`,
    date: '2026-05-28',
    readTime: '4 MIN READ',
    image: 'https://images.unsplash.com/photo-1516257984-b1b4d707412e?auto=format&fit=crop&q=80&w=800',
    author: 'Surging Tide Design Lab'
  },
  {
    id: 'blog-2',
    title: 'DROP 04 PREVIEW: THE CHROME TRIDENT INTRO',
    summary: 'A detailed catalog walkthrough of the upcoming apparel release, highlighting custom fusion metals and puff textures.',
    content: `Our upcoming drop centers around industrial steel reflections in dark ocean depths.\n\nFeaturing advanced heat-fused silver metallics and custom 3D puff designs, Drop 04 explores premium textures that speak directly. We have doubled the loopback cotton density across all silhouettes for heavy structure.\n\nEarly exclusive access will unlock for newsletter members 24 hours prior to general drop time. Stay tuned.`,
    date: '2026-05-20',
    readTime: '3 MIN READ',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=800',
    author: 'Production Editorial Team'
  }
];

export const FAQS = [
  {
    question: 'WHEN IS THE NEXT APPAREL DROP?',
    answer: 'We drop a curated, limited-quantity capsule every first Friday of the month. Subscribe to our newsletter or watch the live drop countdown in our main view to unlock early access 24 hours before the crowd.'
  },
  {
    question: 'CAN I RETURN AN ITEM IF THE SIZE IS OFF?',
    answer: 'Yes. We offer free, hassle-free returns and exchanges within 14 days of shipping. Items must react with their original tags intact and unworn. Check our returns guide to print a direct pre-paid shipping label.'
  },
  {
    question: 'HOW REINFORCED IS THE SILVER TRIDENT BRANDING PRINT?',
    answer: 'Extremely. The chrome-metallic graphics are printed using industrial high-definition heat-fusion technology. They withstand heavy machine cycles without peeling or crack fatigue — just ensure cold washes and wash inside out.'
  },
  {
    question: 'DO YOU SHIP WORLDWIDE?',
    answer: 'Absolutely. We ship out of our central hub on the West Coast. Express orders arrive in 2-3 business days domestically, and 6-10 business days for global destinations.'
  }
];
