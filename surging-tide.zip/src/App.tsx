import React, { useState, useEffect, useRef } from 'react';
import {
  Heart,
  ShoppingBag,
  Star,
  ChevronRight,
  ArrowRight,
  Sparkles,
  MessageSquare,
  Compass,
  Instagram,
  Mail,
  Phone,
  HelpCircle,
  Clock,
  ArrowLeft,
  ChevronDown
} from 'lucide-react';

import { Product, CartItem, Review, BlogPost, LookbookItem, VoteItem } from './types';
import { INITIAL_PRODUCTS, INITIAL_VOTING, LOOKBOOK_ITEMS, BLOG_POSTS, FAQS, IMAGES } from './data';

import Logo from './components/Logo';
import Navbar from './components/Navbar';
import CartDrawer from './components/CartDrawer';
import SearchOverlay from './components/SearchOverlay';
import LoadingScreen from './components/LoadingScreen';
import ProductCard from './components/ProductCard';
import CountdownSection from './components/CountdownSection';
import VotingSection from './components/VotingSection';
import WaveDivider from './components/WaveDivider';
import Toast, { ToastMessage } from './components/Toast';

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [currentView, setCurrentView] = useState<string>('homepage'); // 'homepage' | 'shop' | 'collections-hoodies' | 'collections-tees' | 'collections-jeans' | 'product' | 'about' | 'lookbook' | 'blog' | 'contact' | 'wishlist'
  const [selectedProductId, setSelectedProductId] = useState<string>('');

  // Cart, Wishlist & Shared products persistence
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  
  // Overlay/interactive UI toggles
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Category filter state for shop
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'hoodies' | 'tees' | 'jeans'>('all');
  const [sortOption, setSortOption] = useState<'newest' | 'price-low' | 'price-high' | 'popular'>('newest');
  const [shopLimit, setShopLimit] = useState(4); // Shop load-more state
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  // Custom cursor position trackers
  const [mousePos, setMousePos] = useState({ x: -100, y: -100 });
  const [cursorHovered, setCursorHovered] = useState(false);
  const [cursorPressed, setCursorPressed] = useState(false);

  // Sync state with localStorage on startup
  useEffect(() => {
    const savedCart = localStorage.getItem('surging_cart');
    const savedWish = localStorage.getItem('surging_wishlist');
    const savedProd = localStorage.getItem('surging_products_dynamic');

    if (savedCart) {
      try { setCart(JSON.parse(savedCart)); } catch (e) {}
    }
    if (savedWish) {
      try { setWishlist(JSON.parse(savedWish)); } catch (e) {}
    }
    if (savedProd) {
      try { setProducts(JSON.parse(savedProd)); } catch (e) {}
    }
  }, []);

  const saveCartToStorage = (updatedCart: CartItem[]) => {
    setCart(updatedCart);
    localStorage.setItem('surging_cart', JSON.stringify(updatedCart));
  };

  const saveWishlistToStorage = (updatedWish: string[]) => {
    setWishlist(updatedWish);
    localStorage.setItem('surging_wishlist', JSON.stringify(updatedWish));
  };

  const saveProductsToStorage = (updatedProds: Product[]) => {
    setProducts(updatedProds);
    localStorage.setItem('surging_products_dynamic', JSON.stringify(updatedProds));
  };

  // Toast notifier triggers
  const triggerToast = (type: 'success' | 'info' | 'error' | 'wishlist', text: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, text }]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Custom cursor position listeners
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
      
      // Check if mouse is hovering over interactive tags
      const target = e.target as HTMLElement;
      if (
        target && (
          target.tagName === 'BUTTON' ||
          target.tagName === 'A' ||
          target.tagName === 'INPUT' ||
          target.tagName === 'SELECT' ||
          target.tagName === 'TEXTAREA' ||
          target.closest('button') ||
          target.closest('a') ||
          target.classList.contains('cursor-pointer')
        )
      ) {
        setCursorHovered(true);
      } else {
        setCursorHovered(false);
      }
    };

    const handleMouseDown = () => setCursorPressed(true);
    const handleMouseUp = () => setCursorPressed(false);

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  // Back to top upon view updates
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as any });
  }, [currentView, selectedProductId]);

  // Dynamic Routing Handler
  const handleNavigate = (view: string) => {
    if (view.startsWith('collections-')) {
      const category = view.replace('collections-', '') as 'hoodies' | 'tees' | 'jeans';
      setCategoryFilter(category);
      setCurrentView(`collections-${category}`);
    } else {
      setCurrentView(view);
    }
  };

  const navigateToProduct = (id: string) => {
    setSelectedProductId(id);
    setCurrentView('product');
  };

  // CART INTERACTION CONTROLLERS
  const addToCart = (product: Product, size: string, color: string, qty: number = 1) => {
    const cartItemId = `${product.id}-${size}-${color}`;
    const duplicate = cart.find((item) => item.id === cartItemId);

    let updatedCart: CartItem[];
    if (duplicate) {
      updatedCart = cart.map((item) =>
        item.id === cartItemId ? { ...item, quantity: item.quantity + qty } : item
      );
    } else {
      updatedCart = [...cart, { id: cartItemId, product, selectedSize: size, selectedColor: color, quantity: qty }];
    }

    saveCartToStorage(updatedCart);
    triggerToast('success', `${product.name} (SIZE ${size}) ADDED TO BAG`);
  };

  const handleQuickAddToCart = (product: Product) => {
    // Falls back to first available variants
    addToCart(product, product.sizes[0], product.colors[0], 1);
  };

  const updateCartQuantity = (itemId: string, newQty: number) => {
    const updated = cart.map((item) => (item.id === itemId ? { ...item, quantity: newQty } : item));
    saveCartToStorage(updated);
  };

  const removeCartItem = (itemId: string) => {
    const updated = cart.filter((item) => item.id !== itemId);
    saveCartToStorage(updated);
  };

  const clearCart = () => {
    saveCartToStorage([]);
  };

  // WISHLIST CONTROLLER
  const toggleWishlist = (product: Product) => {
    let updated: string[];
    if (wishlist.includes(product.id)) {
      updated = wishlist.filter((id) => id !== product.id);
      saveWishlistToStorage(updated);
      triggerToast('info', `${product.name} SECURED FROM WISHLIST`);
    } else {
      updated = [...wishlist, product.id];
      saveWishlistToStorage(updated);
      triggerToast('wishlist', `${product.name} PERSISTED TO WISHLIST`);
    }
  };

  // INSTAGRAM PLACES FORM CONTROLLER
  const handleInstagramFollow = () => {
    triggerToast('info', 'RE-ROUTING TO OFFICIAL @SURGINGTIDE SATELLITE');
  };

  // LOAD MORE CONTROLLER (FOR SHOP MOCK LOADER)
  const handleLoadMoreShop = () => {
    setIsLoadingMore(true);
    setTimeout(() => {
      setShopLimit((prev) => prev + 2);
      setIsLoadingMore(false);
      triggerToast('info', 'NEXT DESIGN CAPSULES SYNCED');
    }, 1200);
  };

  // REVIEWS SUBMISSIONS CONTROLLER
  const handleAddReview = (prodId: string, rating: number, author: string, msg: string) => {
    if (!author.trim() || !msg.trim()) {
      triggerToast('error', 'AUTHOR AND MESSAGE BLOCKS OUGHT NOT BE EMPTY');
      return;
    }

    const newRev: Review = {
      id: Math.random().toString(36).substring(2, 9),
      rating,
      comment: msg,
      author,
      date: new Date().toISOString().split('T')[0],
      verified: true,
    };

    const updatedProds = products.map((p) => {
      if (p.id === prodId) {
        const nextReviews = [newRev, ...p.reviews];
        // recalculate aggregate rating
        const sum = nextReviews.reduce((acc, r) => acc + r.rating, 0);
        const nextAvg = parseFloat((sum / nextReviews.length).toFixed(1));
        return {
          ...p,
          reviews: nextReviews,
          rating: nextAvg,
        };
      }
      return p;
    });

    saveProductsToStorage(updatedProds);
    triggerToast('success', 'YOUR REVIEW SECURED ON SECURE ST NODES');
  };

  // CONTACT SUBMISSIONS
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    triggerToast('success', 'YOUR COMMUNICATIVE DEED LOCKED IN');
    const form = e.target as HTMLFormElement;
    form.reset();
  };

  // Dynamic filter products block
  const getFilteredProducts = () => {
    let list = [...products];
    if (categoryFilter !== 'all') {
      list = list.filter((p) => p.category === categoryFilter);
    }

    // Sort order implementations
    if (sortOption === 'price-low') {
      list.sort((a, b) => a.price - b.price);
    } else if (sortOption === 'price-high') {
      list.sort((a, b) => b.price - a.price);
    } else if (sortOption === 'popular') {
      list.sort((a, b) => b.rating - a.rating);
    } else {
      // default newest by code id sorting
      list.sort((a, b) => b.id.localeCompare(a.id));
    }

    return list;
  };

  // Dynamic active product selector
  const activeProduct = products.find((p) => p.id === selectedProductId) || products[0];

  return (
    <div className="bg-[#000000] text-[#E8E8E8] font-sans antialiased relative min-h-screen selection:bg-[#6B7BFF] selection:text-white pb-0">
      
      {/* 1. Cinematic Loading Intro Screen */}
      {isLoading && <LoadingScreen onComplete={() => setIsLoading(false)} />}

      {/* 2. CUSTOM SCREEN DESIGNED GLOWING MOUSE CURSOR */}
      <div
        id="custom-dot-cursor"
        className="fixed w-3 h-3 bg-[#6B7BFF] rounded-full pointer-events-none z-50 transition-transform duration-100 mix-blend-screen hidden md:block"
        style={{
          left: `${mousePos.x}px`,
          top: `${mousePos.y}px`,
          transform: `translate(-50%, -50%) scale(${cursorHovered ? 1.8 : 1} ) scale(${cursorPressed ? 0.6 : 1})`,
          boxShadow: '0 0 10px rgba(107, 123, 255, 1)',
        }}
      />
      <div
        id="custom-ring-cursor"
        className="fixed w-8 h-8 border border-[#C0C0C0] rounded-full pointer-events-none z-50 transition-all duration-300 md:block hidden"
        style={{
          left: `${mousePos.x}px`,
          top: `${mousePos.y}px`,
          transform: `translate(-50%, -50%) scale(${cursorHovered ? 1.4 : 1}) scale(${cursorPressed ? 0.8 : 1})`,
          opacity: 0.6,
        }}
      />

      {/* 4. MAIN FLOATING HEADER & NAVIGATION ACCORDING TO SYSTEM */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        wishlistCount={wishlist.length}
      />

      {/* 5. SIDE CART SLID-OUT DRAWER MODULE */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQuantity={updateCartQuantity}
        onRemoveItem={removeCartItem}
        onClearCart={clearCart}
        onAddToast={triggerToast}
      />

      {/* 6. IMMERSIVE LIVING SEARCH OVERLAY Muted screen */}
      <SearchOverlay
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        products={products}
        onNavigateToProduct={navigateToProduct}
      />

      {/* 7. TOAST FEED STACKS */}
      <div id="toast-notifications-rack" className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 pointer-events-none">
        {toasts.map((t) => (
          <Toast key={t.id} toast={t} onClose={removeToast} />
        ))}
      </div>

      {/* 8. ACTIVE DRIFT CONTROLLER ROUTING DRAWER MODULES ENGINES */}
      <main className="pt-20 sm:pt-24 z-10 select-none overflow-hidden flex flex-col items-center">
        {currentView === 'homepage' && <Homepage products={products} onNavigateToProduct={navigateToProduct} onQuickAddToCart={handleQuickAddToCart} wishlist={wishlist} onToggleWishlist={toggleWishlist} onNavigate={handleNavigate} onAddToast={triggerToast} />}
        {currentView === 'shop' && <Shop products={getFilteredProducts()} originalCount={products.length} categoryFilter={categoryFilter} setCategoryFilter={setCategoryFilter} sortOption={sortOption} setSortOption={setSortOption} shopLimit={shopLimit} handleLoadMoreShop={handleLoadMoreShop} isLoadingMore={isLoadingMore} onNavigateToProduct={navigateToProduct} onQuickAddToCart={handleQuickAddToCart} wishlist={wishlist} onToggleWishlist={toggleWishlist} />}
        {currentView.startsWith('collections-') && <Collections products={getFilteredProducts()} categoryFilter={categoryFilter} onNavigateToProduct={navigateToProduct} onQuickAddToCart={handleQuickAddToCart} wishlist={wishlist} onToggleWishlist={toggleWishlist} />}
        {currentView === 'product' && <ProductDetails product={activeProduct} onAddToCart={addToCart} onToggleWishlist={toggleWishlist} isWishlisted={wishlist.includes(activeProduct.id)} products={products} onNavigateToProduct={navigateToProduct} onAddReview={handleAddReview} />}
        {currentView === 'about' && <About />}
        {currentView === 'lookbook' && <Lookbook onNavigateToProduct={navigateToProduct} />}
        {currentView === 'blog' && <Blog />}
        {currentView === 'contact' && <Contact onContactSubmit={handleContactSubmit} />}
        {currentView === 'wishlist' && <Wishlist wishlist={wishlist} products={products} onNavigateToProduct={navigateToProduct} onToggleWishlist={toggleWishlist} onQuickAddToCart={handleQuickAddToCart} />}
      </main>

      {/* 9. SECURE STANDARD COMMERCE COLLATERAL FOOTER */}
      <footer className="bg-[#04040A] border-t border-[#6B7BFF]/10 py-16 px-6 relative select-none w-full text-zinc-400">
        
        {/* Decorative Watermark wave dividers back */}
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#6B7BFF]/20 to-transparent" />

        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 text-left">
          
          {/* Logo Brand information info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => handleNavigate('homepage')}>
              <Logo iconOnly size="sm"/>
              <span className="font-sans font-black text-white text-xs tracking-[0.3em] uppercase">SURGING TIDE</span>
            </div>
            <p className="text-xs uppercase leading-relaxed text-zinc-500 font-sans">
              RIDE THE STYLE WAVE. BOLD FABRICATIONS AND UNCOMPROMISING GEOMETRICS ENGINEERED FOR THE HARBOR SINCE 2026.
            </p>
            
            {/* Social channels cards links */}
            <div className="flex items-center space-x-4 pt-2">
              <a href="#instagram" onClick={handleInstagramFollow} className="p-2 bg-[#0D0D1A] border border-zinc-800 hover:border-[#6B7BFF] hover:text-[#6B7BFF] rounded-lg transition-all">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="mailto:support@surgingtide.com" className="p-2 bg-[#0D0D1A] border border-zinc-800 hover:border-[#6B7BFF] hover:text-[#6B7BFF] rounded-lg transition-all">
                <Mail className="w-4 h-4" />
              </a>
              <a href="tel:+12345678" className="p-2 bg-[#0D0D1A] border border-zinc-800 hover:border-[#6B7BFF] hover:text-[#6B7BFF] rounded-lg transition-all">
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Nav Links Column */}
          <div>
            <h5 className="font-mono text-[9px] font-bold text-[#C0C0C0] tracking-widest uppercase mb-4">DRY NAV INDEX</h5>
            <ul className="space-y-2 mt-4 text-xs font-sans font-medium tracking-wider">
              {['shop', 'lookbook', 'blog', 'about', 'contact'].map((view) => (
                <li key={view}>
                  <button
                    onClick={() => handleNavigate(view)}
                    className="hover:text-[#6B7BFF] hover:translate-x-1 uppercase transition-all"
                  >
                    {view}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal and information Column */}
          <div>
            <h5 className="font-mono text-[9px] font-bold text-[#C0C0C0] tracking-widest uppercase mb-4">LEGAL SATELLITE</h5>
            <ul className="space-y-2 mt-4 text-xs font-sans font-medium tracking-wider">
              {['RETURNS GUIDE', 'PRIVACY CRITERIA', 'COOKIE CODES', 'SECURE GATEWAY CERTIFICATION'].map((item) => (
                <li key={item}>
                  <button
                    onClick={() => triggerToast('info', `${item} DOCUMENTATION LOADED`)}
                    className="hover:text-[#6B7BFF] hover:translate-x-1 uppercase transition-all text-left block"
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter Input footer card */}
          <div className="space-y-4">
            <h5 className="font-mono text-[9px] font-bold text-[#C0C0C0] tracking-widest uppercase mb-4">JOIN THE HARBOR</h5>
            <p className="text-[10px] text-zinc-500 uppercase leading-normal">
              SECURE REGISTRATION DIRECTLY ON OUR TALLY LIST TO TRIGGER ALERTS BEFORE FUTURE DEBARKATIONS.
            </p>
            
            <form
              onSubmit={(e) => {
                e.preventDefault();
                triggerToast('success', 'SUB DEPLOYED SUCCESSFULLY');
                const inp = e.currentTarget.querySelector('input') as HTMLInputElement;
                if (inp) inp.value = '';
              }}
              className="flex items-center overflow-hidden border border-[#6B7BFF]/20 focus-within:border-[#6B7BFF] bg-black/45 rounded-lg"
            >
              <input
                type="email"
                required
                placeholder="YOUR EMAIL"
                className="px-3 py-2 text-xs font-mono tracking-widest text-[#E8E8E8] placeholder-zinc-700 bg-transparent outline-none uppercase w-full"
              />
              <button
                type="submit"
                className="px-3 bg-[#6B7BFF] text-white hover:opacity-90 transition-all font-sans font-bold text-[10px] sm:text-xs h-full py-2.5 uppercase"
              >
                JOIN
              </button>
            </form>
          </div>

        </div>

        {/* Outer Legal Line */}
        <div className="max-w-7xl mx-auto border-t border-zinc-900 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-left">
          <div className="text-[10px] font-mono tracking-wider text-zinc-600 uppercase">
            © 2026 SURGING TIDE APPAREL ENTERPRISES. ALL RIGHTS PRESERVED. RIDE THE STYLE WAVE.
          </div>
          
          {/* Card row visual symbols */}
          <div className="flex items-center space-x-2 opacity-40 font-mono text-[8px] text-zinc-600 uppercase">
            <span>VES_LINKID</span>
            <span className="w-1 h-3 bg-zinc-800" />
            <span>CRD_LINKID</span>
            <span className="w-1 h-3 bg-zinc-800" />
            <span>PAY_SECURE</span>
          </div>
        </div>

      </footer>

    </div>
  );
}

/* ==========================================
   VIEW SUB-COMPONENTS SECTOR FOR READABILITY
   ========================================== */

// 1. HOMEPAGE VIEW COMPONENT
interface ViewProps {
  products: Product[];
  onNavigateToProduct: (id: string) => void;
  onQuickAddToCart: (product: Product) => void;
  wishlist: string[];
  onToggleWishlist: (product: Product) => void;
  onNavigate: (view: string) => void;
  onAddToast: (type: 'success' | 'info' | 'error' | 'wishlist', text: string) => void;
}

function Homepage({
  products,
  onNavigateToProduct,
  onQuickAddToCart,
  wishlist,
  onToggleWishlist,
  onNavigate,
  onAddToast,
}: ViewProps) {
  const collectionRef = useRef<HTMLDivElement>(null);

  return (
    <div className="w-full text-center">
      
      {/* SECTION 1: HERO CONTAINER (Atmospheric full viewport parallax) */}
      <section className="relative w-full min-h-[90vh] flex flex-col justify-center items-center px-6 overflow-hidden">
        {/* Background static cover rendering */}
        <div className="absolute inset-0 z-0">
          <img
            src={IMAGES.bgWave}
            alt="Swirling energy tidal lines"
            className="w-full h-full object-cover scale-105 filter brightness-50 opacity-40 animate-pulse"
            referrerPolicy="no-referrer"
          />
          {/* Bottom absolute black mask overlay */}
          <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-black to-transparent" />
        </div>

        {/* Center rotating massive trident silver logo seal watermark */}
        <div className="absolute z-0 opacity-10 flex items-center justify-center animate-[spin_100s_linear_infinite] select-none pointer-events-none scale-150">
          <Logo iconOnly size="xl" />
        </div>

        {/* Hero Headlines Block */}
        <div className="relative z-10 max-w-5xl space-y-6">
          <p className="text-[#6B7BFF] text-xs sm:text-sm font-black tracking-[0.4em] uppercase mb-6 animate-fade-in-up">
            New drops. Real quality. Est. 2026.
          </p>
          <h1 className="text-5xl sm:text-[100px] leading-[0.95] sm:leading-[0.9] font-black tracking-tighter text-[#E8E8E8] uppercase max-w-5xl">
            Ride The <span className="text-transparent text-stroke-blue">Style Wave</span>
          </h1>
          <p className="text-xs sm:text-sm text-[#C0C0C0] font-sans uppercase tracking-[0.25em] font-medium max-w-xl mx-auto leading-relaxed pt-2">
            Crafted in deep black, electric blue, and raw silver steels. Built for the cold, made for the crowd.
          </p>

          <div className="pt-8 flex flex-col sm:flex-row items-center justify-center gap-6">
            <button
              onClick={() => onNavigate('shop')}
              className="px-12 py-5 bg-[#6B7BFF] text-white text-xs font-black tracking-[0.3em] uppercase hover:bg-[#5B6BEF] transition-all rounded-none cursor-pointer w-full sm:w-auto"
            >
              Shop Now
            </button>
            <button
              onClick={() => {
                collectionRef.current?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-12 py-5 border-2 border-[#C0C0C0] text-[#C0C0C0] text-xs font-black tracking-[0.3em] uppercase hover:bg-[#C0C0C0] hover:text-black transition-all rounded-none cursor-pointer w-full sm:w-auto"
            >
              Explore Drops
            </button>
          </div>
        </div>

        {/* Scrolling Marquee Branding from Design HTML */}
        <div className="absolute bottom-16 left-0 w-full flex overflow-hidden opacity-25 pointer-events-none z-10 select-none pb-4">
          <div className="animate-marquee flex gap-12 text-3xl sm:text-4xl font-black uppercase tracking-[0.5em] text-[#C0C0C0]">
            <span>Surging Tide</span>
            <span className="text-[#6B7BFF]">•</span>
            <span>Not Just Clothes</span>
            <span className="text-[#6B7BFF]">•</span>
            <span>A Movement</span>
            <span className="text-[#6B7BFF]">•</span>
            <span>Surging Tide</span>
            <span>&nbsp;•&nbsp;</span>
            <span>Surging Tide</span>
            <span className="text-[#6B7BFF]">•</span>
            <span>Not Just Clothes</span>
            <span className="text-[#6B7BFF]">•</span>
            <span>A Movement</span>
            <span className="text-[#6B7BFF]">•</span>
            <span>Surging Tide</span>
          </div>
        </div>

        {/* Bottom micro scroll anchor animation */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 animate-bounce flex flex-col items-center">
          <span className="text-[8px] font-mono tracking-widest text-[#C0C0C0] uppercase">SCROLL DEPTHS</span>
          <ChevronDown className="w-4 h-4 text-[#6B7BFF] mt-1" />
        </div>
      </section>

      {/* WAVE SECTION GRAPHIC DIVIDER */}
      <WaveDivider />

      {/* SECTION 2: BRAND MANIFESTO STATEMENT STATS */}
      <section className="py-24 px-6 bg-[#0a0a0a] text-center relative select-none w-full border-t border-[#C0C0C0]/10">
        <div className="max-w-4xl mx-auto space-y-12">
          <div className="space-y-4">
            <span className="text-[9px] font-mono tracking-[0.4em] text-[#C0C0C0]/60 block uppercase font-bold">BRAND MANIFESTO SEC-02</span>
            <blockquote className="text-2xl sm:text-4xl font-sans font-black tracking-widest text-[#E8E8E8] uppercase italic leading-tight">
              "NOT JUST CLOTHES. A MOVEMENT."
            </blockquote>
            <p className="text-zinc-400 text-xs sm:text-sm uppercase max-w-xl mx-auto leading-relaxed">
              STREETWEAR EMBRACED IN ABSOLUTE LUXURY FORM. DESIGN CONVERSIONS TO WEAR COLD, LIVE BOLD, AND DEFINE THE TIDES.
            </p>
          </div>

          {/* 3 Icons grid stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-6">
            {[
              { title: '100% QUALITY CHECKED', val: '520GSM ORGANICS', detail: 'Dense fabrics constructed to retain geometric architecture forever.' },
              { title: 'RETURNS ASSURED', val: '14 DAYS FREE', detail: 'Hassle-free despatches and capsule adjustments without boundaries.' },
              { title: 'LIVING DROP CADENCE', val: 'MONTHLY CAPSULES', detail: 'Limited runs. High collections democracy. Cast your design ballot.' }
            ].map((stat, i) => (
              <div key={i} className="bg-black border border-[#C0C0C0]/10 p-8 rounded-none flex flex-col items-center hover:border-[#6B7BFF] transition-colors">
                <span className="text-2xl font-black text-[#6B7BFF] drop-shadow-md">0{i+1}</span>
                <h4 className="text-xs font-sans font-black tracking-widest text-[#E8E8E8] uppercase mt-4">{stat.title}</h4>
                <p className="text-[9px] font-mono text-[#C0C0C0] uppercase mt-1 tracking-wider">{stat.val}</p>
                <p className="text-[10px] text-zinc-500 mt-2 leading-relaxed uppercase">{stat.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 3: COLLECTIONS DIVISIONS CATEGORIES TILE Mappings */}
      <section ref={collectionRef} className="py-24 px-6 bg-[#0a0a0a] select-none text-left w-full border-t border-[#C0C0C0]/10">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="flex flex-col md:flex-row justify-between items-baseline border-b border-[#C0C0C0]/10 pb-6 gap-2">
            <h2 className="text-2xl sm:text-4xl font-sans font-black tracking-widest text-[#E8E8E8] uppercase flex items-center">
              THE COLLECTIONS <Sparkles className="w-5 h-5 text-[#6B7BFF] ml-3 animate-pulse" />
            </h2>
            <span className="text-zinc-400 font-sans tracking-wide text-xs uppercase font-medium">SELECT YOUR DESIGN FABRIC CHASSIS</span>
          </div>

          {/* Three large bento tiles side by side */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: 'HOODIES',
                desc: 'Built for the cold, made for the crowd.',
                buttonLabel: 'VEW HOODIES',
                viewId: 'collections-hoodies',
                img: IMAGES.hoodie,
              },
              {
                title: 'TEES',
                desc: 'Simple. Clean. Unmistakable.',
                buttonLabel: 'VEW TEES',
                viewId: 'collections-tees',
                img: IMAGES.tee,
              },
              {
                title: 'JEANS',
                desc: 'Cut different. Worn everywhere.',
                buttonLabel: 'VEW DENIMS',
                viewId: 'collections-jeans',
                img: IMAGES.jeans,
              }
            ].map((tile, i) => (
              <div
                key={i}
                onClick={() => onNavigate(tile.viewId)}
                className="relative h-[420px] rounded-none overflow-hidden group border border-[#C0C0C0]/10 hover:border-[#6B7BFF] hover:shadow-[0_0_25px_rgba(107,123,255,0.15)] scroll-smooth transition-all duration-300 cursor-pointer flex flex-col justify-end"
              >
                {/* Background Image inside card */}
                <div className="absolute inset-0 z-0">
                  <img
                    src={tile.img}
                    alt={tile.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 filter brightness-95 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  {/* Subtle dark layout gradients overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent z-10" />
                </div>

                {/* Details section */}
                <div className="p-6 relative z-11 space-y-2">
                  <h4 className="text-xl sm:text-2xl font-sans font-black tracking-widest text-[#E8E8E8] uppercase">
                    {tile.title}
                  </h4>
                  <p className="text-xs text-zinc-400 font-sans uppercase tracking-wide leading-snug">
                    {tile.desc}
                  </p>
                  
                  <div className="pt-2">
                    <span className="inline-flex items-center space-x-2 px-6 py-3 border border-[#C0C0C0]/20 text-white rounded-none text-[10px] font-sans font-black tracking-widest uppercase transition-colors group-hover:bg-[#6B7BFF] group-hover:border-[#6B7BFF]">
                      <span>{tile.buttonLabel}</span> <ArrowRight className="w-35 h-3.5 text-white" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 4: HORIZONTAL PRODUCT SCROLL CAROUSEL */}
      <section className="py-24 px-6 bg-black select-none text-left w-full relative">
        <div className="max-w-7xl mx-auto space-y-10">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between border-b border-zinc-900 pb-6 gap-2">
            <div>
              <span className="text-[10px] font-mono tracking-[0.4em] text-[#6B7BFF] uppercase block font-bold">THE HIGHLIGHT DROPS INDEX</span>
              <h2 className="text-xl sm:text-3xl font-sans font-black tracking-widest text-white uppercase mt-1">LATEST CAPSULES</h2>
            </div>
            
            <button
              onClick={() => onNavigate('shop')}
              className="text-xs text-[#6B7BFF] font-sans font-bold tracking-widest uppercase hover:text-white flex items-center self-start sm:self-auto cursor-pointer"
            >
              BROWSE ALL CAPSULES <ChevronRight className="w-4 h-4 ml-1" />
            </button>
          </div>

          {/* Scollable track box */}
          <div className="flex overflow-x-auto pb-6 gap-6 scrollbar-none snap-x snap-mandatory">
            {products.map((p) => (
              <div key={p.id} className="min-w-[280px] sm:min-w-[320px] max-w-[320px] snap-start flex">
                <ProductCard
                  product={p}
                  onNavigateToProduct={onNavigateToProduct}
                  onQuickAddToCart={onQuickAddToCart}
                  isWishlisted={wishlist.includes(p.id)}
                  onToggleWishlist={onToggleWishlist}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 5: NEXT DRIFT TIMERS COUNTDOWNS */}
      <WaveDivider inverse />
      <CountdownSection onAddToast={onAddToast} />
      <WaveDivider />

      {/* SECTION 6: COMMUNITY BALLOTS BALLOTING */}
      <VotingSection onAddToast={onAddToast} />

      {/* SECTION 7: BEAUTIFUL FEEDBACK REVIEWS CAROUSELS */}
      <section className="py-24 px-6 bg-[#0D0D1A]/60 select-none text-left w-full border-t border-zinc-950 relative">
        <div className="max-w-5xl mx-auto space-y-12">
          <div className="text-center md:text-left space-y-2">
            <span className="text-[9px] font-mono tracking-[0.5em] text-[#6B7BFF] uppercase block font-bold">SECURE SOCIAL VERIFICATION</span>
            <h2 className="text-2xl sm:text-4xl font-sans font-black tracking-widest text-white uppercase">THE WAVE IS REAL</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { rating: 5, q: "Absurdly heavy cotton structure. Standard hood sits flat, this hoodie stands double structured holding shape exactly like luxury runway garments. Trident color metallic has genuine reflections. Est. 2026 is moving standard forward.", auth: "DANIEL N." },
              { rating: 5, q: "I have standard high end jeans, none fit as clean around the ankle as the Wave Cut. Panel work curves perfectly. Shipping was ridiculously quick, arrived in Los Angeles in 48 hours in dense black vacuum bags.", auth: "SEAN R." },
              { rating: 5, q: "combed cotton tee is seriously dense. Feels stiff, neck is beautifully snug. Definitely premium streetwear build.", auth: "KAELAN J." },
              { rating: 5, q: "Sturdy custom steel zipper tracks. The dual runner is smooth. High level tech clothing details for this price point.", auth: "CHAD M." }
            ].map((usr, ind) => (
              <div key={ind} className="bg-[#05050A] border border-[#6B7BFF]/10 p-6 rounded-2xl flex flex-col justify-between hover:border-[#6B7BFF]/30 transition-colors">
                <div className="space-y-4">
                  <div className="flex items-center space-x-1">
                    {Array.from({ length: usr.rating }).map((_, st) => (
                      <Star key={st} className="w-3.5 h-3.5 text-[#6B7BFF] fill-[#6B7BFF]" />
                    ))}
                  </div>
                  <p className="text-[12px] text-zinc-400 font-sans tracking-wide leading-relaxed uppercase">
                    "{usr.q}"
                  </p>
                </div>

                <div className="flex justify-between items-center mt-6 pt-4 border-t border-zinc-900 text-xs">
                  <span className="font-sans font-bold text-white tracking-widest uppercase">{usr.auth}</span>
                  <span className="text-[9px] font-mono text-emerald-500 uppercase tracking-widest flex items-center bg-emerald-950/20 px-2 py-0.5 rounded border border-emerald-500/10">
                    VERIFIED BUYER
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 8: INSTAGRAM STATIC PLACEMENT */}
      <section className="py-24 px-6 bg-black select-none text-center w-full border-t border-[#6B7BFF]/10 relative">
        <div className="max-w-6xl mx-auto space-y-10">
          <div className="space-y-2">
            <span className="text-[10px] font-mono tracking-[0.5em] text-[#6B7BFF] uppercase block font-bold">SOCIAL SATELLITE</span>
            <h2 className="text-2xl sm:text-4xl font-sans font-black tracking-widest text-white uppercase">@SURGINGTIDE</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              'https://images.unsplash.com/photo-1516257984-b1b4d707412e?auto=format&fit=crop&q=80&w=400',
              'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=400',
              'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&q=80&w=400',
              'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&q=80&w=400',
            ].map((img, i) => (
              <div key={i} className="relative aspect-square overflow-hidden rounded-xl border border-zinc-900 hover:border-[#6B7BFF]/40 group transition-all duration-300">
                <img
                  src={img}
                  alt={`Social look snippet ${i}`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-75 group-hover:brightness-100"
                  referrerPolicy="no-referrer"
                />
                
                {/* Instant overlay on hover */}
                <span className="absolute inset-x-0 bottom-0 py-3 bg-black/80 font-mono text-[9px] tracking-widest text-[#6B7BFF] opacity-0 group-hover:opacity-100 uppercase transition-opacity">
                  SHOP LIFESTYLE
                </span>
              </div>
            ))}
          </div>

          <div className="pt-4">
            <button
              onClick={() => onAddToast('info', 'RE-ROUTING TO OFFICIAL @SURGINGTIDE SATELLITE')}
              className="px-6 py-2.5 border border-[#6B7BFF] text-[#6B7BFF] hover:bg-[#6B7BFF] hover:text-white font-mono text-[10px] tracking-widest uppercase rounded-lg transition-all cursor-pointer"
            >
              FOLLOW THE WAVE CHANNELS
            </button>
          </div>
        </div>
      </section>

    </div>
  );
}

// 2. SHOP CODES CONTAINER
interface ShopProps {
  products: Product[];
  originalCount: number;
  categoryFilter: 'all' | 'hoodies' | 'tees' | 'jeans';
  setCategoryFilter: (cat: 'all' | 'hoodies' | 'tees' | 'jeans') => void;
  sortOption: 'newest' | 'price-low' | 'price-high' | 'popular';
  setSortOption: (opt: 'newest' | 'price-low' | 'price-high' | 'popular') => void;
  shopLimit: number;
  handleLoadMoreShop: () => void;
  isLoadingMore: boolean;
  onNavigateToProduct: (id: string) => void;
  onQuickAddToCart: (product: Product) => void;
  wishlist: string[];
  onToggleWishlist: (product: Product) => void;
}

function Shop({
  products,
  categoryFilter,
  setCategoryFilter,
  sortOption,
  setSortOption,
  shopLimit,
  handleLoadMoreShop,
  isLoadingMore,
  onNavigateToProduct,
  onQuickAddToCart,
  wishlist,
  onToggleWishlist,
}: ShopProps) {
  const visible = products.slice(0, shopLimit);

  return (
    <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 md:px-8 py-10 text-left select-none space-y-12">
      
      {/* Banner Area */}
      <div className="bg-[#0D0D1A] border border-[#6B7BFF]/10 rounded-2xl p-8 sm:p-12 relative overflow-hidden flex flex-col justify-center">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#6B7BFF]/5 rounded-full blur-3xl pointer-events-none" />
        <span className="text-[10px] font-mono tracking-[0.4em] text-[#6B7BFF] uppercase block font-bold mb-2 animate-fade-in-up">
          UNIFIED DROPS HUB // INVENTORY DRIFT
        </span>
        <h1 className="text-3xl sm:text-5xl font-sans font-black tracking-widest text-white uppercase leading-none">
          THE DROP ZONE
        </h1>
        <p className="text-xs sm:text-sm text-zinc-500 uppercase mt-2 max-w-md tracking-wider">
          ACQUIRE ORIGINAL DESIGN CODES. UNCOMPROMISING STREETWEAR CONSTRUCTIONS PERSISTING ACROSS WORLD BOUNDARIES.
        </p>
      </div>

      {/* FILTER BAR SPECS: All / Hoodies / Tees / Jeans + Sorter */}
      <div className="bg-black border border-zinc-900 rounded-xl p-4 flex flex-col sm:flex-row justify-between gap-4 items-center">
        
        {/* Buttons sector */}
        <div className="flex flex-wrap gap-2 justify-center sm:justify-start">
          {[
            { tag: 'all', label: 'ALL DEEDS' },
            { tag: 'hoodies', label: 'HOODIES' },
            { tag: 'tees', label: 'TEES' },
            { tag: 'jeans', label: 'DENIM' }
          ].map((cat) => (
            <button
              key={cat.tag}
              onClick={() => setCategoryFilter(cat.tag as any)}
              className={`px-4 py-2 border rounded-lg text-xs font-mono tracking-widest uppercase transition-all duration-300 cursor-pointer ${
                categoryFilter === cat.tag
                  ? 'bg-gradient-to-r from-[#6B7BFF] to-[#5B6BEF] border-[#6B7BFF] text-white shadow-md'
                  : 'border-zinc-800 text-[#C0C0C0] hover:border-zinc-700 hover:text-white bg-[#0D0D1A]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Sorting Dropdown */}
        <div className="flex items-center space-x-2 w-full sm:w-auto self-stretch sm:self-auto justify-between sm:justify-start">
          <span className="text-[9px] font-mono tracking-widest text-zinc-500 uppercase font-bold text-left whitespace-nowrap">ORD CORRELATION:</span>
          <select
            className="bg-[#0D0D1A] border border-zinc-800 text-xs font-mono tracking-wider text-[#C0C0C0] outline-none px-4 py-2 rounded-lg cursor-pointer uppercase hover:border-[#6B7BFF] focus:border-[#6B7BFF] w-full sm:w-auto"
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value as any)}
          >
            <option value="newest">NEWEST COMMITS</option>
            <option value="price-low">PRICE: DECRESCENT</option>
            <option value="price-high">PRICE: ACCRESCENT</option>
            <option value="popular">VOTE POPULARITY</option>
          </select>
        </div>

      </div>

      {/* Product count stats */}
      <div className="flex justify-between items-center text-xs text-zinc-600 font-mono uppercase tracking-widest py-1 border-b border-zinc-950">
        <span>FETCHED SPECIFICATIONS: {products.length} FILTERS MATCHED</span>
        <span>DRY SYSTEM STABILITY OK</span>
      </div>

      {/* GRID LAYOUTS */}
      {visible.length === 0 ? (
        <div className="py-24 text-center text-zinc-600 font-sans tracking-wide uppercase">
          NO SPECIFICATIONS MATCHED THE SECTOR FILTERS.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {visible.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onNavigateToProduct={onNavigateToProduct}
              onQuickAddToCart={onQuickAddToCart}
              isWishlisted={wishlist.includes(p.id)}
              onToggleWishlist={onToggleWishlist}
            />
          ))}
        </div>
      )}

      {/* Load More Trigger according to spec */}
      {visible.length < products.length && (
        <div className="py-8 flex flex-col items-center">
          <button
            onClick={handleLoadMoreShop}
            disabled={isLoadingMore}
            className="px-8 py-3 bg-[#0D0D1A] border border-[#6B7BFF]/30 hover:border-[#6B7BFF] text-white font-sans font-bold tracking-widest text-xs uppercase rounded-xl transition-all cursor-pointer flex items-center justify-center space-x-3 w-full sm:w-auto"
          >
            {isLoadingMore ? (
              <>
                <span className="w-4 h-4 rounded-full border-2 border-t-transparent border-[#6B7BFF] animate-spin shrink-0" />
                <span>PROCESSING VESSEL ACCESS...</span>
              </>
            ) : (
              <>
                <span>DECRYPT NEXT DESIGN LAYERS</span>
              </>
            )}
          </button>
        </div>
      )}

    </div>
  );
}

// 3. COLLECTION HEADER CODES SPECIFIC VIEW
interface CollectionProps {
  products: Product[];
  categoryFilter: 'hoodies' | 'tees' | 'jeans' | 'all';
  onNavigateToProduct: (id: string) => void;
  onQuickAddToCart: (product: Product) => void;
  wishlist: string[];
  onToggleWishlist: (product: Product) => void;
}

function Collections({
  products,
  categoryFilter,
  onNavigateToProduct,
  onQuickAddToCart,
  wishlist,
  onToggleWishlist,
}: CollectionProps) {
  
  // Custom headers and banners based on spec
  const details = {
    hoodies: {
      headline: 'STAY WARM. STAY SHARP.',
      detail: 'BUILT FOR THE COLD, MADE FOR THE CROWD. OUR HEAVYWEIGHT GEOMETRIC SEAM WORK DRAYS PRESTIGE OVERLAYS.',
      desc: 'Forged with 520GSM combed fleece loopback profiles that preserve geometric structures. Each item features custom-reinforced silver trident motifs.',
    },
    tees: {
      headline: 'THE ESSENTIAL. REDEFINED.',
      detail: 'SIMPLE. CLEAN. UNMISTAKABLE. 280GSM COMED SILHOUETTES COMMITTING ULTIMATE URBAN COMFORT DRAWS.',
      desc: 'Engineered with double-needle ribbed collar structures that resist stretch wear. Perfect thick drapes for active city walks.',
    },
    jeans: {
      headline: 'BUILT DIFFERENT.',
      detail: 'CUT DIFFERENT. WORN EVERYWHERE. JAPANESE RAW SHUTTLE DENIM SEAMED TO DEFINE GEOMETRIC TIDES.',
      desc: 'Finished with custom silver reinforcement hardware and curved structural pocket entries designed with natural mechanical contours.',
    },
    all: {
      headline: 'WAVE CATALOG CHASSIS',
      detail: 'SYSTEM CODES MATCHED',
      desc: ''
    }
  };

  const activeHeader = details[categoryFilter] || details.all;

  return (
    <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 md:px-8 py-10 text-left select-none space-y-12">
      
      {/* High-impact custom banner based on category specification details */}
      <div className="bg-black border border-[#C0C0C0]/15 rounded-none relative overflow-hidden p-8 sm:p-12 flex flex-col justify-center min-h-[250px]">
        {/* Subtle geometric particles background */}
        <div className="absolute top-0 right-0 w-96 h-[250px] bg-[#6B7BFF]/5 rounded-none blur-3xl pointer-events-none" />
        <span className="text-[10px] font-mono tracking-[0.4em] text-[#6B7BFF] uppercase block font-bold mb-2">
          CURATED COLLECTION CAPSULE // {categoryFilter.toUpperCase()}
        </span>
        <h1 className="text-3xl sm:text-5xl font-sans font-black tracking-widest text-[#FFFFFF] uppercase leading-none">
          {activeHeader.headline}
        </h1>
        <p className="text-xs sm:text-sm text-[#C0C0C0] uppercase mt-2 max-w-xl tracking-wider leading-relaxed">
          {activeHeader.detail}
        </p>
        <p className="text-zinc-500 text-[10px] sm:text-xs uppercase mt-3 max-w-lg leading-relaxed font-sans">
          {activeHeader.desc}
        </p>
      </div>

      {/* Separation mark */}
      <div className="flex justify-between items-center text-xs text-zinc-500 font-mono uppercase tracking-widest border-b border-zinc-900 pb-2">
        <span>APPAREL CATALOG DRIFTS ({products.length}) MATCHED</span>
        <span>STABILITY SECURED</span>
      </div>

      {/* Grid view */}
      {products.length === 0 ? (
        <div className="py-24 text-center text-zinc-600 font-sans tracking-wide uppercase">
          NO ITEMS INVENTORY COMMITTED IN {categoryFilter.toUpperCase()} FOR NOW.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onNavigateToProduct={onNavigateToProduct}
              onQuickAddToCart={onQuickAddToCart}
              isWishlisted={wishlist.includes(p.id)}
              onToggleWishlist={onToggleWishlist}
            />
          ))}
        </div>
      )}

    </div>
  );
}

// 4. RICH PRODUCT INSPECTION DETAILS SCREEN
interface ProdDetailProps {
  product: Product;
  isWishlisted: boolean;
  onAddToCart: (p: Product, size: string, color: string, qty: number) => void;
  onToggleWishlist: (p: Product) => void;
  products: Product[];
  onNavigateToProduct: (id: string) => void;
  onAddReview: (prodId: string, rating: number, author: string, msg: string) => void;
}

function ProductDetails({
  product,
  isWishlisted,
  onAddToCart,
  onToggleWishlist,
  products,
  onNavigateToProduct,
  onAddReview,
}: ProdDetailProps) {
  const [activeImg, setActiveImg] = useState(product.primaryImage);
  const [selectedSize, setSelectedSize] = useState(product.sizes[0]);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'description' | 'guide' | 'ship'>('description');

  // Review Form state controllers
  const [rating, setRating] = useState(5);
  const [authorName, setAuthorName] = useState('');
  const [commentArea, setCommentArea] = useState('');

  // Resets local selections upon item change
  useEffect(() => {
    setActiveImg(product.primaryImage);
    setSelectedSize(product.sizes[0]);
    setSelectedColor(product.colors[0]);
    setQuantity(1);
  }, [product]);

  // related items recommendation
  const related = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 3);

  const reviewsBreakdown = {
    total: product.reviews.length,
    average: product.rating,
    star5: product.reviews.filter((r) => r.rating === 5).length,
    star4: product.reviews.filter((r) => r.rating === 4).length,
    star3: product.reviews.filter((r) => r.rating === 3).length,
  };

  const handleReviewFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddReview(product.id, rating, authorName, commentArea);
    setAuthorName('');
    setCommentArea('');
  };

  return (
    <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 md:px-8 py-10 text-left select-none space-y-16">
      
      {/* 2-Panel details setup */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12">
        
        {/* LEFT COMPACT IMAGE GALLERY COL */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Main Visual Display */}
          <div className="aspect-square rounded-none overflow-hidden bg-black border border-[#C0C0C0]/15 relative">
            <img
              src={activeImg}
              alt={product.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Thumbnail track selectors */}
          <div className="flex space-x-4">
            {[product.primaryImage, product.secondaryImage].map((img, i) => (
              <button
                key={i}
                onClick={() => setActiveImg(img)}
                className={`w-20 h-20 rounded-none overflow-hidden border bg-black transition-all cursor-pointer shrink-0 ${
                  activeImg === img ? 'border-[#6B7BFF] shadow-[0_0_10px_rgba(107,123,255,0.4)] scale-102' : 'border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <img
                  src={img}
                  alt={`${product.name} thumbnail ${i}`}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </button>
            ))}
          </div>

        </div>

        {/* RIGHT PROPERTY CONTROLS COL */}
        <div className="lg:col-span-5 flex flex-col justify-between py-2 space-y-6">
          <div className="space-y-4">
            
            {/* Tag/Index and stars statistics */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-[10px] font-mono tracking-[0.4em] text-[#6B7BFF] uppercase font-bold">
                DRY REPLICATE CODE // #{product.id}
              </span>
              <div className="flex items-center space-x-1 py-1 px-2.5 bg-black rounded-none border border-[#C0C0C0]/15">
                <Star className="w-3.5 h-3.5 text-[#6B7BFF] fill-[#6B7BFF]" />
                <span className="font-mono text-xs font-bold text-white">{product.rating}</span>
                <span className="text-[9px] font-mono text-zinc-500 uppercase">({product.reviews.length})</span>
              </div>
            </div>

            {/* Product Bold Name */}
            <h1 className="text-2xl sm:text-4xl font-sans font-black tracking-widest text-[#FFFFFF] uppercase leading-[1.1]">
              {product.name}
            </h1>

            {/* Price Line */}
            <p className="text-xl sm:text-2xl font-mono font-black text-[#6B7BFF]">
              ${product.price} USD
            </p>

            {/* Short Specs statement */}
            <p className="text-xs sm:text-sm text-zinc-400 font-sans leading-relaxed uppercase">
              {product.description}
            </p>

            <div className="border-t border-zinc-900 my-4 pt-4 space-y-4">
              
              {/* SIZE OPTIONS */}
              <div className="space-y-2">
                <label className="block text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-bold">
                  SIZE CONFIGURATION: <span className="text-white">{selectedSize}</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setSelectedSize(sz)}
                      className={`h-10 min-w-10 px-3 border rounded-none text-xs font-mono font-bold tracking-widest uppercase transition-all cursor-pointer ${
                        selectedSize === sz
                          ? 'border-[#6B7BFF] bg-[#6B7BFF]/10 text-[#6B7BFF] scale-102'
                          : 'border-zinc-800 text-[#C0C0C0] hover:border-zinc-700 bg-black/40'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>

              {/* COLOUR OPTIONS */}
              <div className="space-y-2">
                <label className="block text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-bold">
                  COLOUR CODES: <span className="text-white">{selectedColor}</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.colors.map((clr) => (
                    <button
                      key={clr}
                      onClick={() => setSelectedColor(clr)}
                      className={`px-4 py-2 border rounded-none text-xs font-mono font-bold tracking-widest uppercase transition-all cursor-pointer ${
                        selectedColor === clr
                          ? 'border-[#6B7BFF] bg-[#6B7BFF]/10 text-[#6B7BFF] scale-102'
                          : 'border-zinc-800 text-[#C0C0C0] hover:border-zinc-700 bg-black/40'
                      }`}
                    >
                      {clr}
                    </button>
                  ))}
                </div>
              </div>

              {/* QUANTITY SECTION */}
              <div className="space-y-2">
                <label className="block text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-bold">
                  AMASSED QUANTITY: <span className="text-white">{quantity}</span>
                </label>
                
                <div className="inline-flex items-center space-x-3 border border-[#C0C0C0]/15 rounded-none bg-black px-3 py-1.5 justify-center">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-1 text-zinc-500 hover:text-white font-mono text-sm"
                  >
                    -
                  </button>
                  <span className="font-mono text-sm text-white px-2">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-1 text-zinc-500 hover:text-white font-mono text-sm"
                  >
                    +
                  </button>
                </div>
              </div>

            </div>
          </div>

          {/* ACTION BUTTON CHEST CODES */}
          <div className="flex flex-col sm:flex-row gap-3 border-t border-zinc-900 pt-6">
            <button
              onClick={() => onAddToCart(product, selectedSize, selectedColor, quantity)}
              id="product-add-to-cart-button"
              className="flex-1 h-14 bg-[#6B7BFF] hover:bg-[#5B6BEF] text-white rounded-none font-sans font-black tracking-[0.3em] text-xs uppercase cursor-pointer flex items-center justify-center space-x-2 transition-colors duration-150"
            >
              <ShoppingBag className="w-4 h-4 text-white shrink-0" />
              <span>COMMIT TO CONTAINER</span>
            </button>

            <button
              onClick={() => onToggleWishlist(product)}
              id="product-wishlist-toggle"
              className={`p-4 h-14 border rounded-none flex items-center justify-center cursor-pointer transition-colors ${
                isWishlisted
                  ? 'border-[#6B7BFF] text-[#6B7BFF] bg-[#6B7BFF]/5 hover:bg-[#6B7BFF]/10'
                  : 'border-zinc-800 hover:border-zinc-700 text-[#C0C0C0] hover:text-white'
              }`}
              title="Add to Wishlist"
            >
              <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-[#6B7BFF]' : ''}`} />
            </button>
          </div>

        </div>

      </div>

      {/* MID-PAGE TABBED SECTION DRIP CHRONICLES */}
      <div className="border border-[#C0C0C0]/10 bg-black rounded-none p-6 sm:p-10 space-y-6">
        
        {/* tabs bar */}
        <div className="flex flex-wrap border-b border-zinc-900 pb-3 gap-4">
          {[
            { id: 'description', label: 'SPECIFICATION DETAILS' },
            { id: 'guide', label: 'SIZE REFERENCE MATRIX' },
            { id: 'ship', label: 'VESSEL LOGISTICS' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`text-xs font-mono tracking-widest uppercase pb-2 transition-all cursor-pointer relative ${
                activeTab === tab.id ? 'text-[#6B7BFF] font-bold' : 'text-zinc-500 hover:text-zinc-400'
              }`}
            >
              <span>{tab.label}</span>
              {activeTab === tab.id && (
                <span className="absolute bottom-[-13px] left-0 right-0 h-[2.5px] bg-[#6B7BFF]" />
              )}
            </button>
          ))}
        </div>

        {/* Tab contents */}
        <div className="pt-4 font-sans text-xs sm:text-sm text-zinc-400 leading-relaxed uppercase text-left">
          {activeTab === 'description' && (
            <div className="space-y-6">
              <p className="border-l-2 border-[#6B7BFF]/30 pl-4 py-1 italic text-zinc-300">
                {product.longDescription}
              </p>
              
              <div className="space-y-2 pt-2">
                <h5 className="font-mono text-[9px] font-bold text-[#C0C0C0] tracking-widest uppercase">CONSTRUCTION TRACE SPEC:</h5>
                <ul className="list-disc pl-5 mt-2 space-y-1.5 text-xs text-zinc-500">
                  {product.details.map((det, i) => (
                    <li key={i}>{det}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'guide' && (
            <div className="space-y-6">
              <p className="text-zinc-500">
                ALL PRODUCTS ARE CRAFTED CUTS INCITING INTENDED STREETWEAR OVERSIZED OR RELAXED SHAPES. REFER TO THICK MEASURES MATRIX.
              </p>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left text-[10px] font-mono divide-y divide-zinc-950 mt-4 border border-zinc-950 bg-black/60 rounded-none overflow-hidden shadow-inner">
                  <thead>
                    <tr className="text-zinc-600 bg-zinc-950">
                      <th className="p-3">SIZE INDEX</th>
                      <th className="p-3">CHEST MEASURE</th>
                      <th className="p-3">LENGTH TRACK</th>
                      <th className="p-3">SLEEVE OUTLINES</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-950 text-zinc-400">
                    <tr><td className="p-3 text-white font-bold">SMALL S</td><td className="p-3">22" INCHES</td><td className="p-3">27" INCHES</td><td className="p-3">24.5" INCHES</td></tr>
                    <tr><td className="p-3 text-white font-bold">MEDIUM M</td><td className="p-3">24" INCHES</td><td className="p-3">28" INCHES</td><td className="p-3">25.0" INCHES</td></tr>
                    <tr><td className="p-3 text-white font-bold">LARGE L</td><td className="p-3">26" INCHES</td><td className="p-3">29" INCHES</td><td className="p-3">25.5" INCHES</td></tr>
                    <tr><td className="p-3 text-white font-bold">X-LARGE XL</td><td className="p-3">28" INCHES</td><td className="p-3">30" INCHES</td><td className="p-3">26.0" INCHES</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'ship' && (
            <div className="space-y-4">
              <h5 className="font-mono text-[9px] font-bold text-[#C0C0C0] tracking-widest uppercase">VESSEL DISPATCH SCHEDULING:</h5>
              <p className="text-zinc-500">
                EVERY DRIFT TRANSITS COLD PITCH VACUUM ENCLOSURES. ORDERS ARRIVE DOMESTICALLY IN 2-3 BUSINESS CYCLES. FREE INITIATED TRANSACTIONS FOR OVERAGE VALUES BENT TO $150 USD.
              </p>
              <h5 className="font-mono text-[9px] font-bold text-[#C0C0C0] tracking-widest uppercase mt-4">14 CYCLES EXCHANGE GUARANTEE:</h5>
              <p className="text-zinc-500">
                NOT ENTIRELY COMPATIBLE WITH DESIGN RESISTANCE? WE OFFER SECURE HASSLE-FREE CARGO RE-RETURNS UPON INITIAL INTEGRITY INTACTS within 14 CYCLES.
              </p>
            </div>
          )}
        </div>

      </div>

      {/* LIVE CUSTOMER REVIEWS DYNAMIC SUBMISSIONS PANEL SECTOR */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12 border-t border-zinc-900 pt-12">
        
        {/* Left Stats breakdown Column */}
        <div className="lg:col-span-4 space-y-6">
          <div className="space-y-2">
            <span className="text-[9px] font-mono tracking-[0.4em] text-[#6B7BFF] uppercase block font-bold">USER RESONATOR RATINGS</span>
            <h3 className="text-xl sm:text-2xl font-sans font-black tracking-widest text-[#FFFFFF] uppercase">VERIFIED OPINIONS</h3>
          </div>

          {/* Average metrics rating */}
          <div className="p-6 bg-black border border-[#C0C0C0]/10 rounded-none text-center space-y-2">
            <h2 className="text-4xl sm:text-6xl font-mono font-black text-[#6B7BFF]">
              {product.rating}
            </h2>
            <div className="flex justify-center items-center space-x-1">
              {Array.from({ length: 5 }).map((_, st) => (
                <Star
                  key={st}
                  className={`w-4 h-4 ${
                    st < Math.round(product.rating) ? 'text-[#6B7BFF] fill-[#6B7BFF]' : 'text-zinc-800'
                  }`}
                />
              ))}
            </div>
            <p className="text-[10px] text-zinc-500 font-mono tracking-widest uppercase">
              BASED ON {reviewsBreakdown.total} CRITIQUES
            </p>
          </div>

          {/* star ratio map */}
          <div className="space-y-2 pt-2">
            {[
              { stars: 5, count: reviewsBreakdown.star5 },
              { stars: 4, count: reviewsBreakdown.star4 },
              { stars: 3, count: reviewsBreakdown.star3 },
            ].map((br) => {
              const pct = product.reviews.length > 0 ? Math.round((br.count / product.reviews.length) * 100) : 0;
              return (
                <div key={br.stars} className="flex items-center space-x-3 text-[10px] font-mono text-zinc-500">
                  <span className="w-10 whitespace-nowrap">{br.stars} STAR</span>
                  <div className="flex-1 h-1.5 bg-zinc-950 rounded-none overflow-hidden">
                    <div className="h-full bg-[#6B7BFF] rounded-none" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="w-8 text-right font-bold text-zinc-400">{pct}%</span>
                </div>
              );
            })}
          </div>

        </div>

        {/* Right Actual reviews and Submitting custom form column */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* Form write reviewer */}
          <form onSubmit={handleReviewFormSubmit} className="p-5 sm:p-6 bg-black border border-[#C0C0C0]/10 rounded-none space-y-4">
            <h4 className="text-xs font-mono font-black tracking-widest text-[#FFFFFF] uppercase">
              DEEP RESISTANCE OPINION SUBMIT
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Star select clicker */}
              <div className="space-y-2">
                <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase">CONV CONNOTATION RATE</label>
                <div className="flex items-center space-x-2 bg-black px-3 py-2 rounded-none border border-zinc-800">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setRating(i + 1)}
                      className={`text-[#6B7BFF] hover:scale-110 transition-transform cursor-pointer`}
                    >
                      <Star className={`w-5 h-5 ${i < rating ? 'fill-[#6B7BFF]' : 'text-zinc-800'}`} />
                    </button>
                  ))}
                </div>
              </div>

              {/* Author name details */}
              <div className="space-y-2">
                <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase">RESONATOR NAME (AUTHOR)</label>
                <input
                  type="text"
                  required
                  className="w-full h-11 px-3 bg-black border border-zinc-800 focus:border-[#6B7BFF] rounded-none text-xs text-[#E8E8E8] placeholder-zinc-700 outline-none uppercase font-mono tracking-widest"
                  placeholder="E.G., DAMON SHAW"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                />
              </div>

            </div>

            {/* Comment details */}
            <div className="space-y-2">
              <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase">RESONANCE CRITIQUE MESSAGE</label>
              <textarea
                required
                className="w-full p-3 bg-black border border-zinc-800 focus:border-[#6B7BFF] rounded-none text-xs text-[#E8E8E8] placeholder-zinc-700 outline-none uppercase font-mono tracking-wider min-h-[80px]"
                placeholder="YOUR TEXT MESSAGE DETAILS TO THE PUBLIC HARBOR DEEDS"
                value={commentArea}
                onChange={(e) => setCommentArea(e.target.value)}
              />
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 bg-zinc-900 hover:border-[#6B7BFF] border border-zinc-800 hover:text-white text-zinc-400 font-mono text-[10px] tracking-widest uppercase rounded-none transition-all cursor-pointer shadow-md"
            >
              TRANSMIT COMMITTED BALLOT
            </button>
          </form>

          {/* Actual Review Cards track */}
          <div className="space-y-4 text-left">
            {product.reviews.map((rev) => (
              <div key={rev.id} className="p-5 bg-black border border-[#C0C0C0]/10 rounded-none space-y-3">
                <div className="flex justify-between items-baseline flex-wrap gap-2">
                  <div className="flex items-center space-x-3">
                    <span className="font-sans font-bold text-xs text-white uppercase tracking-wider">{rev.author}</span>
                    {rev.verified && (
                      <span className="text-[8px] font-mono text-[#6B7BFF] uppercase tracking-widest bg-[#6B7BFF]/5 px-2 py-0.5 rounded-none border border-[#6B7BFF]/10">
                        VERIFIED SECURE BUY
                      </span>
                    )}
                  </div>
                  <span className="text-[9px] font-mono text-[#6B7BFF] tracking-widest">{rev.date}</span>
                </div>

                <div className="flex items-center space-x-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3 h-3 ${i < rev.rating ? 'text-[#6B7BFF] fill-[#6B7BFF]' : 'text-zinc-900'}`}
                    />
                  ))}
                </div>

                <p className="text-xs text-zinc-400 uppercase leading-relaxed font-sans font-medium tracking-wide">
                  "{rev.comment}"
                </p>
              </div>
            ))}
          </div>

        </div>

      </div>

      {/* RELATED CAROUSEL AREA */}
      {related.length > 0 && (
        <div className="space-y-8 pt-12 border-t border-zinc-900">
          <h2 className="text-xl sm:text-2xl font-sans font-black tracking-widest text-white uppercase">
            YOU MIGHT ALSO LIKE
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {related.map((item) => (
              <div key={item.id} className="flex">
                <ProductCard
                  product={item}
                  onNavigateToProduct={onNavigateToProduct}
                  onQuickAddToCart={() => onAddToCart(item, item.sizes[0], item.colors[0], 1)}
                  isWishlisted={isWishlisted}
                  onToggleWishlist={onToggleWishlist}
                />
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}

// 5. MOVING STORY ABOUT MANIFESTO PAGE
function About() {
  return (
    <div className="max-w-4xl w-full mx-auto px-4 sm:px-6 md:px-8 py-10 text-left select-none space-y-16">
      
      {/* Intro Block */}
      <div className="text-center space-y-6 border-b border-zinc-900 pb-12">
        <span className="text-[10px] font-mono tracking-[0.5em] text-[#6B7BFF] uppercase block font-bold">MANIFESTO SEC-00</span>
        <h1 className="text-3xl sm:text-6xl font-sans font-black tracking-widest text-[#FFFFFF] uppercase leading-[1.05] italic">
          "WE DIDN'T WAIT FOR AN INVITATION."
        </h1>
        <p className="text-zinc-400 font-sans text-xs sm:text-sm uppercase max-w-xl mx-auto leading-relaxed tracking-wider">
          FORGED FROM THE WATER REEFS OF TOMORROW. ESTABLISHED TO DELIVER PRISTINE COLD FUSION MATERIALS BEYOND COMMERCIAL SLOP CODES.
        </p>
      </div>

      {/* Story Text Box Panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-[#05050A] border border-zinc-900 rounded-2xl p-6 sm:p-10">
        <div className="space-y-4">
          <span className="text-[9px] font-mono text-[#6B7BFF] uppercase tracking-widest block">BACKGROUND ROOT</span>
          <h3 className="text-xl font-sans font-black tracking-widest text-white uppercase">TIDE RISE FOUNDRY</h3>
          <p className="text-xs text-zinc-400 font-sans uppercase leading-relaxed font-semibold">
            Surging Tide was born in 2026 with one mission — bring high-quality style to everyone, not just those who can afford it. The wave is for everyone.
          </p>
          <p className="text-zinc-500 text-[10px] sm:text-xs uppercase leading-relaxed">
            Every thread traces our centralized control lines. We discard default fast fashion cycles, utilizing heavyweight 14.5oz Japanese denims and ultra thick 520GSM organic loopback cotton.
          </p>
        </div>

        <div className="aspect-[4/3] rounded-xl overflow-hidden bg-black border border-zinc-950 relative">
          <img
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=800"
            alt="Storefront raw background"
            className="w-full h-full object-cover filter brightness-50"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>

      {/* BRAND VALUES CARD DEEDS */}
      <div className="space-y-8">
        <h4 className="text-center font-sans font-black tracking-widest text-white uppercase text-base sm:text-lg">CORE INTENSITY MATRIX VALUES</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { tag: '01', title: 'RAW QUANTITY', desc: 'Fabric density constructed under rigorous pressure. Stiff loopback frames that retain premium visual drape shapes.' },
            { tag: '02', title: 'DEMOCRATIC TIDES', desc: 'Active community voting. Cast design suggestions to directly outline next drop codes.' },
            { tag: '03', title: 'UNAPOLOGETIC FORMS', desc: 'Zero corporate filler lines. Raw, literal titles paired with bold electric blues and deep metal silver sheets.' },
          ].map((val) => (
            <div key={val.tag} className="p-6 bg-[#0D0D1A] rounded-2xl border border-[#6B7BFF]/10 text-left space-y-4">
              <span className="font-mono text-xs font-bold text-[#6B7BFF] block">{val.tag} // CORE</span>
              <h5 className="font-sans font-black tracking-widest text-white text-sm uppercase">{val.title}</h5>
              <p className="text-[10px] sm:text-xs text-zinc-500 uppercase leading-relaxed">{val.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Founder block Quote according to spec */}
      <div className="border border-[#6B7BFF]/20 bg-gradient-to-r from-black to-[#0D0D1A] rounded-2xl p-6 sm:p-10 text-center relative overflow-hidden">
        <p className="text-xs font-mono tracking-widest text-[#6B7BFF] uppercase mb-2">FOUNDATIONAL WORDS</p>
        <blockquote className="text-lg sm:text-2xl font-sans font-black tracking-widest text-white uppercase leading-snug italic max-w-xl mx-auto">
          "THE STYLE CURRENT BELONGS TO THOSE WHO DESIGN IT FROM WATERBED DEPTHS. CHROME CORNERS COMPLY."
        </blockquote>
        <p className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase mt-4">
          — CO-FOUNDER DIRECT DEED, SURGING TIDE 2026
        </p>
      </div>

    </div>
  );
}

// 6. EDITORIAL SCROLL LOOKBOOK PAGE
function Lookbook({ onNavigateToProduct }: { onNavigateToProduct: (id: string) => void }) {
  return (
    <div className="max-w-4xl w-full mx-auto px-4 sm:px-6 md:px-8 py-10 text-left select-none space-y-16">
      
      {/* Intro */}
      <div className="text-center space-y-3">
        <span className="text-[10px] font-mono tracking-[0.5em] text-[#6B7BFF] uppercase block font-bold">DROP PRESTIGE GRAPH CODES</span>
        <h1 className="text-3xl sm:text-5xl font-sans font-black tracking-widest text-white uppercase">THE EDITORIAL</h1>
        <p className="text-zinc-500 font-sans text-xs uppercase tracking-wide max-w-md mx-auto">
          MINIMAL COSTE CONTEXT. MAXIMUM VISUAL INTEGRITY SHAPE LINES. LOOKBOOK CHRONICLES.
        </p>
      </div>

      {/* Editorial blocks track */}
      <div className="space-y-12">
        {LOOKBOOK_ITEMS.map((item, index) => (
          <div
            key={item.id}
            className={`flex flex-col md:flex-row bg-[#050510]/50 border border-zinc-950 rounded-2xl overflow-hidden shadow-2xl items-center ${
              index % 2 === 1 ? 'md:flex-row-reverse' : ''
            }`}
          >
            {/* Left image visual */}
            <div className="w-full md:w-1/2 aspect-[4/5] overflow-hidden bg-zinc-950 relative">
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover hover:scale-102 transition-transform duration-1000"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Right text outlines */}
            <div className="w-full md:w-1/2 p-6 sm:p-10 space-y-6 flex flex-col justify-center">
              <span className="text-[9px] font-mono text-[#6B7BFF] uppercase tracking-widest block font-bold">
                WAVE STUDY NO_0{index+1}
              </span>
              <h3 className="text-xl sm:text-2xl font-sans font-black tracking-widest text-white uppercase">
                {item.title}
              </h3>
              <p className="text-[11px] sm:text-xs text-zinc-400 uppercase leading-relaxed font-medium">
                {item.subtitle}
              </p>

              <div className="pt-2">
                <button
                  onClick={() => onNavigateToProduct(item.productId)}
                  className="px-5 py-2.5 bg-gradient-to-r from-zinc-900 to-black hover:border-[#6B7BFF] border border-zinc-800 hover:text-white text-zinc-400 font-mono text-[10px] tracking-widest uppercase rounded-lg transition-all cursor-pointer block"
                >
                  SHOP THIS LOOK
                </button>
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}

// 7. BLOG POSTS READ MATRIX PAGE
function Blog() {
  const [activePost, setActivePost] = useState<BlogPost | null>(null);

  if (activePost) {
    return (
      <div className="max-w-3xl w-full mx-auto px-4 sm:px-6 py-10 text-left select-none space-y-8 animate-fade-in animate-pulse">
        <button
          onClick={() => setActivePost(null)}
          className="flex items-center text-xs font-mono tracking-widest text-[#6B7BFF] hover:text-white uppercase transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" /> RETURN TO RECORDS
        </button>

        <div className="aspect-[16/9] w-full bg-zinc-950 rounded-2xl overflow-hidden border border-zinc-900">
          <img
            src={activePost.image}
            alt={activePost.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>

        <div className="space-y-4 border-b border-zinc-900 pb-6">
          <div className="flex justify-between items-center text-[10px] font-mono text-zinc-500 uppercase tracking-widest">
            <span>BY {activePost.author}</span>
            <span>{activePost.date} // {activePost.readTime}</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-sans font-black tracking-widest text-white uppercase leading-snug">
            {activePost.title}
          </h1>
        </div>

        {/* Dynamic content rendering with split paragraphs to maintain clean structure */}
        <div className="text-zinc-400 text-xs sm:text-sm leading-relaxed uppercase space-y-6 font-sans font-medium tracking-wide">
          {activePost.content.split('\n\n').map((para, i) => (
            <p key={i} className="border-l-2 border-[#6B7BFF]/20 pl-4">
              {para}
            </p>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl w-full mx-auto px-4 sm:px-6 md:px-8 py-10 text-left select-none space-y-12">
      
      {/* Intro */}
      <div className="text-center space-y-3">
        <span className="text-[10px] font-mono tracking-[0.5em] text-[#6B7BFF] uppercase block font-bold">EDITORIAL INTELLIGENCE LOGS</span>
        <h1 className="text-3xl sm:text-5xl font-sans font-black tracking-widest text-white uppercase">THE CHRONICLES</h1>
        <p className="text-zinc-500 font-sans text-xs uppercase tracking-wide max-w-md mx-auto">
          IN-DEPTH SPECIFICATIONS, INTERVIEW CORSETS, AND DROP PREVIEWS STRAIGHT FROM OUR WAVE SYSTEMS.
        </p>
      </div>

      {/* Grid of articles */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {BLOG_POSTS.map((post) => (
          <div
            key={post.id}
            onClick={() => setActivePost(post)}
            className="bg-black border border-[#C0C0C0]/10 rounded-none overflow-hidden group hover:border-[#6B7BFF]/40 transition-all duration-300 cursor-pointer flex flex-col justify-between"
          >
            <div className="aspect-[16/10] overflow-hidden bg-black relative">
              <img
                src={post.image}
                alt={post.title}
                className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-750"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex justify-between text-[8px] sm:text-[9px] font-mono tracking-widest text-[#6B7BFF] uppercase">
                  <span>{post.date}</span>
                  <span>{post.readTime}</span>
                </div>
                <h4 className="text-sm font-sans font-black tracking-widest text-white group-hover:text-[#6B7BFF] transition-colors uppercase leading-snug line-clamp-2">
                  {post.title}
                </h4>
                <p className="text-[10px] text-zinc-500 leading-relaxed uppercase line-clamp-2">
                  {post.summary}
                </p>
              </div>

              <div className="pt-2">
                <span className="text-[10px] font-mono tracking-widest text-[#C0C0C0] uppercase group-hover:text-[#6B7BFF] transition-colors flex items-center">
                  READ ARTICLE CHRONICLES <ArrowRight className="w-3.5 h-3.5 ml-1" />
                </span>
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
}

// 8. CONTACT FORMFAQ ACCORDION VIEWS
function Contact({ onContactSubmit }: { onContactSubmit: (e: React.FormEvent) => void }) {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  return (
    <div className="max-w-5xl w-full mx-auto px-4 sm:px-6 md:px-8 py-10 text-left select-none space-y-16">
      
      {/* Intro */}
      <div className="text-center space-y-3">
        <span className="text-[10px] font-mono tracking-[0.5em] text-[#6B7BFF] uppercase block font-bold">WAVE COMMUNICATIONS RELAY</span>
        <h1 className="text-3xl sm:text-5xl font-sans font-black tracking-widest text-white uppercase">GET IN TOUCH</h1>
        <p className="text-zinc-500 font-sans text-xs uppercase tracking-wide max-w-md mx-auto">
          NEED EXPEDITED HARBOR DIRECTIVES OR CORRESPONDENCE REGARDING YOUR DESIGN ACQUISITIONS? CONTACT TRANSMISSION.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12">
        
        {/* Left Info Columns */}
        <div className="lg:col-span-4 space-y-6">
          <h4 className="text-sm font-mono tracking-widest text-white uppercase font-black">ST WIRE CHANNELS</h4>
          
          {[
            { label: 'EMAIL TRANSMISSION', val: 'SUPPORT@SURGINGTIDE.COM', detail: 'DEEP ACCESS LINES 24/7' },
            { label: 'SATELLITE NET (INSTAGRAM)', val: '@SURGINGTIDE', detail: 'STYLE SENSORS STABILITY' },
            { label: 'VOICE WIRE', val: '+1 (800) SURG-TIDE', detail: 'SECURE SPECTRUM LINE' },
          ].map((item) => (
            <div key={item.label} className="p-4 bg-black rounded-none border border-[#C0C0C0]/10 text-left">
              <span className="block text-[8px] font-mono text-zinc-500 uppercase tracking-widest">{item.label}</span>
              <span className="block text-xs font-mono font-bold text-[#6B7BFF] uppercase mt-1 tracking-wider">{item.val}</span>
              <span className="block text-[9px] text-zinc-600 uppercase mt-1 leading-none">{item.detail}</span>
            </div>
          ))}
        </div>

        {/* Right Contact Form Column */}
        <div className="lg:col-span-8 p-6 sm:p-8 bg-black border border-[#C0C0C0]/10 rounded-none">
          <form onSubmit={onContactSubmit} className="space-y-4">
            <h4 className="text-xs font-mono tracking-widest text-[#C0C0C0] uppercase font-bold">EMIT ENVELOPE TRANSMIT Packet</h4>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase">CORR IDENTITY (YOUR NAME)</label>
                <input
                  type="text"
                  required
                  className="w-full h-11 px-3 bg-black border border-zinc-800 focus:border-[#6B7BFF] rounded-none text-xs text-white outline-none font-mono uppercase tracking-widest"
                  placeholder="E.G., DAMON SHAW"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase">CORR SENDER LINK (EMAIL)</label>
                <input
                  type="email"
                  required
                  className="w-full h-11 px-3 bg-black border border-zinc-800 focus:border-[#6B7BFF] rounded-none text-xs text-white outline-none font-mono uppercase tracking-widest"
                  placeholder="EXPLAINER_LINKID@CORR.COM"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-[9px] font-mono text-zinc-500 tracking-widest uppercase">PACKET STATEMENT BODY (MESSAGE)</label>
              <textarea
                required
                className="w-full p-3 bg-black border border-zinc-800 focus:border-[#6B7BFF] rounded-none text-xs text-white outline-none min-h-[120px] font-mono tracking-wider uppercase"
                placeholder="YOUR COMMUNICATIVE DATA TO SURGED INQUISITION SECTOR"
              />
            </div>

            <button
              type="submit"
              className="w-full h-12 bg-[#6B7BFF] hover:bg-[#5B6BEF] text-white rounded-none text-xs font-sans font-black tracking-[0.3em] uppercase transition-all shadow-md cursor-pointer"
            >
              LAUNCH COMMUNICATION BEACON
            </button>
          </form>
        </div>

      </div>

      {/* FAQS DRAWER ACCORDIONS ACORDERS IN SPEC */}
      <div className="space-y-8 pt-12 border-t border-zinc-999">
        <h3 className="text-center font-sans font-black tracking-widest text-[#FFFFFF] uppercase text-base sm:text-lg">COMMON INQUIRY MATRIX</h3>
        
        <div className="max-w-2xl mx-auto space-y-3">
          {FAQS.map((faq, index) => {
            const isOpen = openFaq === index;
            return (
              <div
                key={index}
                className="bg-black border border-[#C0C0C0]/10 rounded-none overflow-hidden transition-all duration-300"
              >
                {/* trigger */}
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full px-5 py-4 flex justify-between items-center bg-black hover:bg-neutral-900 text-left transition-colors cursor-pointer"
                >
                  <span className="font-mono font-bold text-xs tracking-wider text-zinc-200 uppercase leading-snug">
                    {faq.question}
                  </span>
                  <ChevronDown className={`w-4 h-4 text-[#6B7BFF] shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* slider */}
                {isOpen && (
                  <div className="px-5 py-4 border-t border-zinc-950 text-xs font-sans uppercase leading-relaxed text-zinc-400 font-medium animate-fade-in text-left">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}

// 9. PERSISTENT LOCAL WISHLIST PAGE
interface WishProps {
  wishlist: string[];
  products: Product[];
  onNavigateToProduct: (id: string) => void;
  onToggleWishlist: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
}

function Wishlist({
  wishlist,
  products,
  onNavigateToProduct,
  onToggleWishlist,
  onQuickAddToCart,
}: WishProps) {
  const savedItems = products.filter((p) => wishlist.includes(p.id));

  return (
    <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 md:px-8 py-10 text-left select-none space-y-12">
      
      {/* Intro header */}
      <div className="bg-black border border-[#C0C0C0]/15 rounded-none p-8 text-left relative overflow-hidden">
        <span className="text-[10px] font-mono tracking-[0.4em] text-[#6B7BFF] uppercase block font-bold mb-1">
          WISHLIST INTEGRITY NODES // ARCHIVE
        </span>
        <h1 className="text-2xl sm:text-4xl font-sans font-black tracking-widest text-[#FFFFFF] uppercase">
          YOUR SECURED VAULT
        </h1>
        <p className="text-xs text-zinc-500 uppercase mt-1">
          CAPSULES CHOSEN FOR IMMEDIATE TRACK TRANSITS FOR THE FUTURE INCOMING MONTHLY DROPS.
        </p>
      </div>

      {savedItems.length === 0 ? (
        <div className="py-24 text-center space-y-4">
          <p className="text-zinc-600 font-sans tracking-wide uppercase">
            YOUR SECURED VAULT IS EMPTY FOR NOW.
          </p>
          <span className="text-[10px] text-zinc-700 font-mono block">SECURE DRIFT OK</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {savedItems.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onNavigateToProduct={onNavigateToProduct}
              onQuickAddToCart={onQuickAddToCart}
              isWishlisted={true}
              onToggleWishlist={onToggleWishlist}
            />
          ))}
        </div>
      )}

    </div>
  );
}
